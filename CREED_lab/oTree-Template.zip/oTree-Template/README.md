# oTree-Template
 This is a template for oTree experimental app useful for running experiments in the lab. 

## Timeline
- before (welcome + consent)
- intro (instrucitons)
- main (expeirmental game)
- outro (demographics + payment)

## Treatment Allocation
None currently

## Participant Labels
Add '?participant_label=Bob' to the end of the URL provided to join the session.

## Quizzes
- quiz 1 has option to go back to redo instructions (i.e. forward to app *intro2*)
- quiz 2 has option to read instructions at bottom of the page. Answers must be correct to move on from this
- within intro and intro2 'reread instructions' takes people straight onto the next round to read them in the same app again. 


# Exp_Hidden-Mistakes
 This is the oTree folder for Hidden Mistakes. It contains 3 apps. Before (welcome, consent) Intro (instructions, quiz), Main (actual game) and outro (demographics and results) are as the names suggest. *main* has all the code for the game (including round rematching and treatment allocation).

## Timeline

## Treatment Allocation

## Participant Labels
Add '?participant_label=Bob' to the end of the URL provided to join the session.

## Quizzes
- quiz 1 has option to go back to redo instructions (i.e. forward to app *intro2*)
- quiz 2 has option to read instructions at bottom of the page. Answers must be correct to move on from this
- within intro and intro2 'reread instructions' takes people straight onto the next round to read them in the same app again. 


# Instruction previews

The template's standalone instruction-preview generator lives at
`../../ExpExperts/previews/generate_instructions_preview.py`. It is wired to
ExpExperts' instruction variables, so it does not run against this app as-is.

If coauthors need a shareable preview of this pilot's instructions, either
adapt that script (the instruction blocks here live in
`../intro/instructions_text.html` and take the variables listed in
`intro/__init__.py::instruction_vars`), or simply open the running app's demo
session and click through the instruction pages.

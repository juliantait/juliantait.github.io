# exp_pilots — Calibration Pilot (oTree)

oTree implementation of the **calibration pilot** specified in
[`../LaTeX/pilot_design.tex`](../LaTeX/pilot_design.tex) (the authoritative
design doc — reconcile this app against it whenever it changes). Built on the
project's oTree-Template conventions and reusing the **same allocation task
and scoring rule** as [`../ExpExperts`](../ExpExperts).

**One paragraph.** Single-player, no groups, no discussion, no vote, no WTP.
The task is framed as **coconut islands**: 1,000 islands, 800 with stable
production (beta = 0) and 200 growing (beta > 0, stated as whole coconuts per
100 years). Each round shows one island's production in n observation years of
a 100-year window (`y = baseline + beta*(t - 50) + eps`, `sigma = 2.5`,
`baseline` integer uniform 40–80 per round, **displayed values rounded to
whole coconuts** — the integers ARE the stimulus); the true state is redrawn
EVERY round from the 0.8/0.2 prior. On ONE screen they place a **BET** (100
points split between "Stable" and "Growing", same interface and binarised
quadratic scoring rule, Hossain & Okui 2013, as ExpExperts) — the bet is the
one and only elicited object (no separate guess, no confidence slider). 3
blocks x 8 rounds = 24 rounds in production (SEE THE WARNING BELOW — currently
3 per block for testing); the three n values of the participant's (invisible)
ROLE are shown in blocks whose order is randomised per participant. Payment:
£1 base + up to £0.50 for each of **two rounds drawn at random from all
rounds**. Runs on Prolific in GBP.

> ## ⚠️ BEFORE REAL LAUNCH ON PROLIFIC — CHECKLIST
>
> This app is currently configured for **testing**, not for the real run.
> The single authoritative copy of this checklist is the `BEFORE REAL LAUNCH`
> block at the top of `settings.py` (`PRELAUNCH_REQUIRED`), which is
> **machine-checked at import** — the server prints on every start exactly which
> settings are still on testing values.
>
> **Manual item (must be changed by hand):**
>
> | setting | now | required for the real study | why it matters |
> |---|---|---|---|
> | `rounds_per_block` | **3** | **8** | 3 collects well under half the intended rounds per participant, leaving the pilot underpowered. It **cannot** be fixed from a session config afterwards: oTree fixes `C.NUM_ROUNDS` from `DESIGN_DEFAULTS` at *import*, and a config may run fewer rounds but never more — while this says 3, no config can run 8. |
>
> **Automatic item (nothing to remember):**
>
> The testing-only **skip buttons** (skip instructions / fill the quiz with the
> correct answers) are gated on oTree's own `DEBUG` setting, not on a custom
> flag. When `DEBUG` is false neither button renders, and the correct quiz
> answers are never sent to the browser at all. There is no switch to turn off.
>
> Launching with a testing value produces **no error** — the study just quietly
> collects the wrong thing. Restart the server and confirm the banner reads
> `pre-launch checklist CLEAN` before collecting real data.

## Treatments

| Level | Variable | Values | Balance |
|---|---|---|---|
| between | BETA ARM | initial run: {0, 0.02}, {0, 0.03} per year (2 or 3 coconuts per century) | block-randomised |
| between | ROLE (invisible) | NOVICE: n in {3,4,5}; EXPERT: n in {15,20,30} | block-randomised |
| within | block order | 1 of 6 permutations of the role's three n values | block-randomised |

The 1- and 4-coconut arms ({0, 0.01}, {0, 0.04}) are fully configured as the
follow-up session config `pilot_followup_beta14` (frozen instruction examples
included), ready to run as a later session.

Assignment (`before/treatment_assignment.py`) deals participants from
repeatedly shuffled copies of the full combo cross (2 ROLES x 2 BETA ARMS in
the initial run), so **any prefix of arrivals is balanced to within one unit
per combo** — 160 participants give exactly 40 per (ROLE x BETA ARM) cell.
Block-order permutations are balanced the same way. The RNG is seeded from the
session code (override with the `assignment_seed` session-config param), so a
session reproduces its assignment.

Run `.venv/bin/python verify_randomisation.py` to re-check all of this plus
the DGP; it simulates hundreds of sessions and exits non-zero on any failure.
Current status: **all checks pass** (cell balance, prefix balance, block-order
uniformity, 0.8/0.2 prior, year grid, raw noise mean/SD, displayed =
round(raw), baseline uniformity, rounding-error variance 1/12, and
OLS-from-displayed unbiasedness with the rounding-inflated sampling SD from
`../reports/integer_rounding_effects.md`).

## Parameters — all in `settings.py`

Every design quantity lives in `DESIGN_DEFAULTS` (inherited by every session
config; each config may override). Nothing is hard-coded in flow logic:

- DGP: `beta_pairs`, `prior`, `islands_total`, `sigma_eps`, `baseline_min`,
  `baseline_max`, `x_min`, `x_max`, `x_mode`
- ROLE n-subsets: `n_novice`, `n_expert` (one entry per block; the two lists
  must be the same length — **the number of blocks is their length**)
- Structure: `rounds_per_block` (rounds per session = blocks x rounds_per_block)
  — **currently 3 for testing; production value is 8, see the checklist above**
- Payment: `base_payment`, `scoring_prize` (per-round prize),
  `paid_rounds_total` (drawn from ALL rounds), `quiz_bonus` (0 disables)
- Prolific: `cc_code`, `noconsent_code` (per config; replace before launch)
- Testing: `verify_quiz`, `assignment_seed`

The single caveat (same as ExpExperts): oTree fixes `C.NUM_ROUNDS` at import,
so `main/__init__.py` derives it from `SESSION_CONFIG_DEFAULTS` at import
time. A session config may imply FEWER rounds than that (later rounds are
skipped) but never more (session creation raises).

## Rounding: the integers are the stimulus

Displayed production is `round(y_continuous)`; **every derived quantity the
app stores — `beta_hat`, `se`, `llr`, `posterior`, the plot itself — is
computed from the displayed integers**, never from the raw continuous draws.
The raw draws are stored alongside (in `xy_data.y_raw`) ONLY to verify the
randomness is genuine: rounding can make realised draws look less random than
they are. Deriving anything from the raws would describe a stimulus the
participants never saw. `../reports/integer_rounding_effects.md` shows the
rounding itself is inferentially harmless (no slope attenuation, sampling SD
inflated by 0.66%, Bayes risk moved < 0.2 pp). The LLR/posterior marginalise
the unknown baseline (flat prior on the intercept), reducing to the closed
form in that report.

## App flow

`app_sequence = ['before', 'intro', 'main', 'outro']`

- **before** — welcome + consent (Prolific ID capture); balanced treatment
  assignment at session creation. No consent -> skips straight to the outro
  no-consent ending.
- **intro** — instruction pages (coconut-island story; one page per
  `instruction-block` in `intro/instructions_text.html`, including the noise
  table computed from `sigma_eps`) + the 4-question comprehension quiz
  (`intro/quiz_items.py`; cannot proceed until all correct; wrong submissions
  are counted for the optional first-attempt bonus).
- **main** — per round: `BlockStart` (only on each block's first round: says
  the number of surviving records changes, never the count) then
  `AllocationScreen` (chart + the 100-point Stable/Growing bet on one screen,
  with the "how the points pay" info panel; response time recorded;
  `min_view_seconds` lock before the control unlocks).
- **outro** — draws the paid rounds (`paid_rounds_total` at random from ALL
  rounds), scores them with the binarised rule, shows the breakdown, returns
  to Prolific with `cc_code`.

## Frozen instruction examples

The worked example pair on the instructions page (`intro/example_stimuli.py`) is
**frozen, not drawn at runtime**. Every participant with the same n sees exactly
the same illustration; nothing on that code path touches an RNG.

- **One pair per n** (3, 4, 5, 15, 20, 30). The participant sees the pair for
  their **first block's** n. The stable example is shared across BETA ARMS
  (its true slope is 0 either way); the growing example is stored per
  `(n, beta_pos)` — 24 of them, covering all four arms so the follow-up
  configs work unchanged.
- **Real draws, not invented coordinates**: the real DGP (baseline uniform
  40–80, `eps ~ N(0, 2.5^2)`, displayed integers) on the same year grid as
  the task.
- **Selected by percentile, not by extremity.** 200,000 candidates per cell were
  sorted by the OLS slope fitted to the DISPLAYED integers; the stable example
  is the **25th percentile** (so it tilts *downward* — the pedagogical point
  that the weather alone can look like a trend) and the growing example is the
  **75th percentile** (clearly upward, but a draw 1 in 4 rounds beats — not
  cherry-picked to look dramatic).

**Do not replace these with a live draw.** At small n a freshly drawn growing
example frequently does not look growing, so a live draw would sometimes teach
nothing or actively contradict its own caption. Regenerate only with the same
percentile method, and record the new fitted slopes in the module docstring.

## Data recorded (per round, on the `main` player)

`assigned_role`, `beta_pos`, `block_number`, `round_in_block`, `n_points`,
`true_beta`, `state_is_pos`, `baseline`, **`xy_data`** (JSON of the exact
realised years `x`, the DISPLAYED integers `y`, and the raw continuous draws
`y_raw` at full double precision), `allocation_pos_pct`, `rt_ms`, plus
derived-for-convenience `beta_hat`, `se`, `llr`, `posterior` (all computed
from — and reconstructable from — the DISPLAYED integers). Participant-level:
`pilot_role`, `pilot_beta_pair`, `pilot_block_perm`, `pilot_block_ns`,
`pilot_cell`, `failed_attempts`, `task_records`. Outro: `bonus_total`,
`earned`, `payment_detail` (JSON of the drawn paid rounds).

Export via the oTree admin (Data tab) or `otree export`; bonuses for Prolific
come from the outro app's `bonus_total`, matched on the participant label.

## Run locally

```bash
cd exp_pilots
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/otree devserver          # http://localhost:8000 -> Demo
```

Tests (full-flow bots for all configs + the randomisation checks):

```bash
.venv/bin/otree test pilot_test
.venv/bin/otree test pilot
.venv/bin/otree test pilot_followup_beta14
.venv/bin/python verify_randomisation.py
```

## Deployment — Mac mini, experiment.juliantait.eu

Follows the hosting pattern in the MacMini repo
(`deepdive/hosting-otree.md` / `hosting-otree-detail.md`): a standalone Docker
container behind the existing Cloudflare Tunnel. This app uses **port 8102**
(8090 = otree-demo, 8101 = ExpExperts test container).

> **NOTE (Julian):** every command in this section is **Mac-side** — bossman
> cannot run them. Run them in a Terminal on the Mac mini.

### 1. Build and run the container

```bash
# on the Mac mini
cd ~/path/to/Experts && git pull        # or clone juliantait/Experts
cd exp_pilots

docker build -t exp-pilots .
docker volume create exp-pilots-db      # keeps data across container restarts
docker run -d \
  --name exp-pilots \
  --restart unless-stopped \
  --memory 512m \
  -p 8102:8102 \
  -e OTREE_ADMIN_PASSWORD='<choose-a-strong-password>' \
  -e OTREE_SECRET_KEY="$(openssl rand -hex 32)" \
  -v exp-pilots-db:/app/data \
  exp-pilots

docker logs exp-pilots   # expect: "pilot_test bound to exp_pilots -> ..."
curl -sI http://localhost:8102/room/exp_pilots   # expect 200
```

Notes:
- `start.sh` only wipes the database when it is missing or `RESET_DB=1` is
  passed — a container restart mid-study does **not** delete participant data.
- For the real run, additionally pass `-e OTREE_PRODUCTION=1` (turns DEBUG
  off) and `-e OTREE_AUTH_LEVEL=STUDY`. Then verify static files still serve:
  `curl -sI http://localhost:8102/static/global/style.css` (expect 200; if it
  404s, drop `OTREE_PRODUCTION=1` — see the hosting doc's known constraint).

### 2. Point experiment.juliantait.eu at the container

Edit `~/.cloudflared/config.yml`: change the `experiment.juliantait.eu`
ingress service to this container's port (**this repoints the shell away from
the old otree-demo on 8090**):

```yaml
ingress:
  - hostname: experiment.juliantait.eu
    service: http://localhost:8102
  - hostname: projects.juliantait.eu
    service: http://localhost:8080
  - service: http_status:404
```

Then promote it with the standard 4-line sudo block (keeps the root-owned
LaunchDaemon config in sync — the dual-config gotcha causes intermittent
200/404 otherwise):

```bash
sudo cp /etc/cloudflared/config.yml /etc/cloudflared/config.yml.bak.$(date +%Y%m%d-%H%M%S)
sudo cp ~/.cloudflared/config.yml /etc/cloudflared/config.yml
sudo launchctl stop com.cloudflare.cloudflared
sleep 2
sudo launchctl start com.cloudflare.cloudflared
```

Verify (any 404 in the loop = configs still diverge):

```bash
curl -sI https://experiment.juliantait.eu/room/exp_pilots    # expect HTTP/2 200
for i in $(seq 1 20); do
  curl -s -o /dev/null -w "%{http_code} " https://experiment.juliantait.eu/room/exp_pilots
done; echo
```

### 3. Launch on Prolific

1. Replace `cc_code` / `noconsent_code` in `settings.py` with the codes from
   the Prolific study, rebuild the container (`docker stop exp-pilots &&
   docker rm exp-pilots`, then step 1 again — the volume keeps the DB).
2. In the oTree admin (`https://experiment.juliantait.eu` — log in with the
   admin password), create a **`pilot`** session with **160** participants.
3. Put the session-wide link in the Prolific study URL, with the label param:
   `https://experiment.juliantait.eu/join/<code>?participant_label={{%PROLIFIC_PID%}}`
4. Base reward £1 (matches `base_payment`); pay bonuses afterwards via
   Prolific bulk bonus from the data export (outro `bonus_total`).

See `prolific/README.md` for details.

## File map

```
settings.py                      ALL design parameters + session configs + room
before/treatment_assignment.py   balanced ROLE x BETA-ARM assignment (pure logic + oTree hook)
before/__init__.py               consent page, Prolific ID, no-consent routing
intro/instructions_text.html     instruction pages (coconut-island story)
intro/quiz_items.py              the 4 comprehension questions
intro/example_stimuli.py         FROZEN worked-example draws (one pair per n; never live)
main/__init__.py                 round setup (fresh draw per round), BlockStart, AllocationScreen
main/stimulus.py                 DGP (baseline + trend + noise, integer display), OLS,
                                 LLR/posterior (baseline marginalised), noise table, chart SVG
main/scoring.py                  binarised scoring rule (identical to ExpExperts)
main/allocation_screen.html      ONE screen: chart + the 100-point Stable/Growing bet
main/widget_allocation.html      100-point bet control (live per-side totals + proportional bar)
_static/global/css/base.css      CENTRAL design system: every page inherits it
_static/global/css/allocation.css  bespoke styling for the bet widget + chart ONLY
outro/payment_rule.py            paid rounds drawn from ALL rounds, scored
outro/__init__.py                payment computation, Results / NoConsent endings
verify_randomisation.py          simulation check of assignment + DGP (run standalone)
Dockerfile / start.sh            container: prodserver on 8102, room binding, DB kept
*/tests.py                       full-flow oTree bots (otree test pilot / pilot_test / pilot_followup_beta14)
```

## Known deviations / notes

- `pilot_design.tex` is being synced to this implementation in a separate
  task; until then this app (built to the coconut-island brief, 2026-07-30)
  is ahead of the tex — **re-reconcile `intro/instructions_text.html` when
  the tex settles**.
- The tex welcome text mentions a quiz bonus placeholder [Y]; the agreed
  payment for this pilot is £1 base + up to 2 x £0.50, so `quiz_bonus`
  defaults to 0 (the sentence auto-hides). Set it in the config to enable.
- The study runs on Prolific in GBP (`REAL_WORLD_CURRENCY_CODE='GBP'`).
- Prolific tab-switch/AI monitor (Part 2 of the guide) is not wired in.
- The stale pre-coconut preview artifacts (`instructions_preview.html`,
  `preview_flow.html`, `instructions_clarity_review.md`) show the OLD
  abstract-plots design; regenerate or ignore them.

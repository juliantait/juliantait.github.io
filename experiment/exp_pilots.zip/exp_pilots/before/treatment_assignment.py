"""
Treatment assignment for the calibration pilot.

Runs once (round 1 of the `before` app, via `creating_session`) and writes the
full between-participant treatment onto participant fields:

  1. BETA ARM         -- one of cfg['beta_pairs'], fixed for all rounds
                         (per-year slopes; e.g. [0.0, 0.02] = the 2-coconuts-
                         per-century arm).
  2. ROLE             -- 'NOVICE' or 'EXPERT'; sets ONLY which n-list the
                         participant's blocks use. Invisible: no label, no
                         framing, no difference in task, instructions or pay.
  3. BLOCK ORDER      -- within-participant: which n goes in which block,
                         a permutation of the role's n-list.

BALANCE. Cells must fill EVENLY (40 per cell at 160), so treatments are NOT
drawn independently per participant. Instead we use block randomisation:
the full cross of ROLE x BETA ARM (2*2 = 4 combos in the initial run) is
repeated in independently shuffled batches and dealt out in participant order.
Any prefix of the sequence is therefore balanced to within one unit per combo
(so dropout/partial recruitment cannot skew cells), and 160 participants give
exactly 40 per (ROLE x BETA ARM) cell. Block-order permutations are balanced
the same way over the len(n_list)! permutations.

The RNG is seeded from a stable per-session value (cfg['assignment_seed'] if
given, else the session code), so a session always reproduces its assignment.

All quantities come from the session config -- nothing here is hard-coded.
This module deliberately does not import oTree: verify_randomisation.py reuses
the pure functions below without an oTree installation.
"""

import itertools
import random

ROLES = ['NOVICE', 'EXPERT']

# Balancing over all block-order permutations is only sensible while the
# factorial is small; beyond this many blocks we fall back to uniform shuffles.
MAX_BLOCKS_FOR_EXACT_PERMUTATION_BALANCE = 4


def num_blocks(cfg):
    """Number of blocks, derived from the per-role n-lists (must match)."""
    if len(cfg['n_novice']) != len(cfg['n_expert']):
        raise ValueError(
            "n_novice and n_expert must have the same length (one entry per block); "
            f"got {cfg['n_novice']} and {cfg['n_expert']}"
        )
    return len(cfg['n_novice'])


def total_rounds(cfg):
    """Rounds per participant, derived (never hard-coded)."""
    return num_blocks(cfg) * cfg['rounds_per_block']


def cell_combos(cfg):
    """The full cross of the between-participant treatments (ROLE x BETA ARM)."""
    return [
        dict(role=role, beta_pair_index=bp)
        for role in ROLES
        for bp in range(len(cfg['beta_pairs']))
    ]


def _block_randomised_stream(items, count, rng):
    """`count` draws dealt from repeated, independently shuffled copies of `items`.

    Every prefix is balanced to within one unit per item -- the property that
    keeps treatment cells even under dropout or partial recruitment.
    """
    out = []
    while len(out) < count:
        batch = list(items)
        rng.shuffle(batch)
        out.extend(batch)
    return out[:count]


def block_order_choices(cfg):
    """All permutations of block indices (6 for three blocks)."""
    return list(itertools.permutations(range(num_blocks(cfg))))


def assign_sequence(n_participants, cfg, rng):
    """Return one assignment dict per participant, balanced as documented above.

    Each dict has: role, beta_pair (list), beta_pos,
    block_perm (tuple of block indices), block_ns (n shown in block 1, 2, ...),
    cell ('ROLE|beta_pos').
    """
    combos = _block_randomised_stream(cell_combos(cfg), n_participants, rng)

    perms = block_order_choices(cfg)
    if num_blocks(cfg) <= MAX_BLOCKS_FOR_EXACT_PERMUTATION_BALANCE:
        block_perms = _block_randomised_stream(perms, n_participants, rng)
    else:
        block_perms = [tuple(rng.sample(range(num_blocks(cfg)), num_blocks(cfg)))
                       for _ in range(n_participants)]

    assignments = []
    for combo, perm in zip(combos, block_perms):
        beta_pair = list(cfg['beta_pairs'][combo['beta_pair_index']])
        n_list = cfg['n_novice'] if combo['role'] == 'NOVICE' else cfg['n_expert']
        assignments.append(dict(
            role=combo['role'],
            beta_pair=beta_pair,
            beta_pos=beta_pair[1],
            block_perm=perm,
            block_ns=[n_list[i] for i in perm],
            cell=f"{combo['role']}|{beta_pair[1]}",
        ))
    return assignments


def assign_treatments(subsession):
    """oTree entry point: write one balanced assignment per participant."""
    if subsession.round_number != 1:
        return

    cfg = subsession.session.config
    players = list(subsession.get_players())

    seed = cfg.get('assignment_seed') or subsession.session.code
    rng = random.Random(seed)

    assignments = assign_sequence(len(players), cfg, rng)
    for player, a in zip(players, assignments):
        part = player.participant
        part.pilot_role = a['role']
        part.pilot_beta_pair = a['beta_pair']
        part.pilot_beta_pos = a['beta_pos']
        part.pilot_block_perm = list(a['block_perm'])
        part.pilot_block_ns = a['block_ns']
        part.pilot_cell = a['cell']

    print(
        f"[treatment_assignment] {len(players)} participants -> balanced over "
        f"{len(cell_combos(cfg))} combos, {len(block_order_choices(cfg))} block orders"
    )

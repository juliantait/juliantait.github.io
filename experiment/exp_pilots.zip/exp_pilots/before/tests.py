from otree.api import Bot, Submission, expect

from . import Welcome, NoConsentWithdrawal

# Bot participant 2 declines consent to exercise the no-consent routing
# (withdrawal page in this app, then the outro fallback ending); everyone
# else completes the study.
NOCONSENT_BOT_ID = 2


class PlayerBot(Bot):
    def play_round(self):
        consent = self.player.id_in_subsession != NOCONSENT_BOT_ID

        # Treatment assignment ran at session creation — check it landed.
        part = self.participant
        expect(part.pilot_role in ('NOVICE', 'EXPERT'), True)
        expect(len(part.pilot_block_ns), len(self.session.config['n_novice']))
        expect(part.pilot_beta_pair in self.session.config['beta_pairs'], True)

        yield Submission(
            Welcome, dict(consent=consent, prolific_id=f'BOT{self.player.id_in_subsession}'),
            check_html=False)

        if not consent:
            # The bot lands on the withdrawal page (the runner asserts the
            # page class matches). A real non-consenter leaves via the
            # redirect button; the bot advances past the page to exercise
            # the outro fallback.
            yield Submission(NoConsentWithdrawal, check_html=False)

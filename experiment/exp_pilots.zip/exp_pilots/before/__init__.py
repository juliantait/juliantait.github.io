from otree.api import *

from . import treatment_assignment

doc = """
Entry app: welcome + consent (Prolific), and the one-shot balanced treatment
assignment (before/treatment_assignment.py) at session creation. Participants
who decline consent see a withdrawal page (NoConsentWithdrawal) that returns
them to Prolific with the no-consent completion code.
"""

PROLIFIC_COMPLETE_URL = 'https://app.prolific.com/submissions/complete?cc='


class C(BaseConstants):
    NAME_IN_URL = 'before'
    PLAYERS_PER_GROUP = None
    NUM_ROUNDS = 1


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    consent = models.BooleanField(
        widget=widgets.RadioSelect,
        choices=[[True, 'I consent and want to take part'],
                 [False, 'I do not consent']],
        label='')
    prolific_id = models.StringField(blank=True)  # auto-filled from the URL


def creating_session(subsession: Subsession):
    treatment_assignment.assign_treatments(subsession)


# PAGES

class Welcome(Page):
    template_name = 'before/welcome_consent.html'
    form_model = 'player'
    form_fields = ['consent', 'prolific_id']

    @staticmethod
    def vars_for_template(player: Player):
        cfg = player.session.config
        return {
            'base_payment': cu(cfg['base_payment']),
        }

    @staticmethod
    def before_next_page(player: Player, timeout_happened):
        part = player.participant
        part.failed_attempts = 0
        part.task_records = []
        part.consented = player.consent
        part.finish_reason = 'completed' if player.consent else 'noconsent'
        # Numeric exit coding (additive; mirrors the fields above for export).
        # consent: 1 = consented, 0 = declined. Decliners route to
        # NoConsentWithdrawal and out, so they get their terminal code here:
        # completed = -333 (no consent). Completers' completed = 1 is set at the
        # final outro step (outro/Results), not here.
        part.consent = 1 if player.consent else 0
        if not player.consent:
            part.completed = -333
        # Prolific matches submissions on the participant label. The study URL
        # sets it via ?participant_label={{%PROLIFIC_PID%}} (see README); the
        # hidden-field capture is a fallback for direct ?PROLIFIC_PID=... links.
        if player.prolific_id and not part.label:
            part.label = player.prolific_id
        elif part.label and not player.prolific_id:
            player.prolific_id = part.label

class NoConsentWithdrawal(Page):
    """Shown ONLY to participants who declined consent. The withdraw button
    sends them to Prolific's completion URL with the no-consent code, which
    registers the submission as returned/screened out. Consenters never see
    this page and continue to the instructions."""
    template_name = 'before/no_consent_withdrawal.html'

    @staticmethod
    def is_displayed(player: Player):
        return player.field_maybe_none('consent') is False

    @staticmethod
    def js_vars(player: Player):
        code = player.session.config['noconsent_code']
        return dict(completionlink=PROLIFIC_COMPLETE_URL + str(code))

    @staticmethod
    def app_after_this_page(player: Player, upcoming_apps):
        # Non-consenters normally leave via the redirect button on this page.
        # If one advances anyway (e.g. by re-posting the page), skip every
        # remaining app so they can never reach the instructions or the task;
        # outro/NoConsent then serves as the fallback ending.
        return upcoming_apps[-1]


page_sequence = [Welcome, NoConsentWithdrawal]

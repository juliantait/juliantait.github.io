# Clarity review: pilot participant instructions

Scope: `intro/instructions_text.html` (source of truth), cross-checked against
`LaTeX/pilot_design.tex` (Instructions section), the rendered
`instructions_preview.html`, and the two widget partials
(`main/widget_allocation.html`, `main/widget_confidence.html`). Also checked
`main/allocation_screen.html`, `main/stimulus.py`, and
`intro/example_stimuli.py` where the instructions make claims about the task.

Audience assumed: Prolific general public, no stats background, phone or
laptop, skimming, nobody to ask. SUGGESTIONS ONLY, nothing edited.

Overall verdict: these are short, mostly plain, and honest. The skeleton is
good. The problems are a handful of specific mismatches and jargon spots, not
the overall design.

---

## What is already good (keep in any revision)

- **Length.** Three screens, short paragraphs, one idea each. Rare and valuable.
- **Frequency framing of the prior** ("60 plots out of 100"), far better for
  lay readers than "probability 0.6". Keep the framing (see #7 for a tweak).
- **The both-ways noise sentence** is explicit and bolded in both directions:
  "look positive even when the true slope is 0" and "look flat when the true
  slope is positive". The words land; the figures are what lag (see #10).
- **The zero-example caption admits the tilt**: "That tilt is not real, it is
  only noise." Honest and memorable.
- **Real practice widgets, not screenshots**, with "try them now" and "Nothing
  here is recorded". This is the single best comprehension device on the page.
- **The honesty property is stated simply and truthfully**, with detail behind
  the ? popup instead of a scoring formula in the main flow. Right call.
- **The independence sentence** ("the last plot tells you nothing about the
  next") pre-empts the gambler's fallacy in ten words.
- **The task-screen lock explains itself** with a live countdown ("Take a
  moment to look at the plot. You can answer in N seconds."), so the unlisted
  3-second lock is mostly self-healing (see #14).
- **Parameterisation** means testing and real-run text both read correctly.
- Bolding is genuinely sparing and sits on load-bearing phrases.

---

## Ranked suggestions (most comprehension gain first)

### 1. The red line is in the examples but NOT in the task, and nobody says so
- **Location:** "The task" block, red-line paragraph (instructions_text.html
  ~line 70); confirmed in `main/stimulus.py` (`show_fit=False` is the only
  value the task uses).
- **Problem:** the instructions introduce the red best-fit line on the worked
  examples with no hint that the real plots will be dots only. A participant
  will reach plot 1, look for the red line, not find it, and either think the
  page is broken or mentally draw their own "best guess" line because the
  instructions told them that is what the red line was. This is the biggest
  single expectation mismatch in the flow.
- **Suggestion:** add one sentence at the end of that paragraph, bolded:
  "In the experiment itself you will see **only the dots, no red line**. It is
  drawn here just to show you how misleading the overall tilt can be."

### 2. The confidence scale's low end is ambiguous
- **Location:** `widget_confidence.html` anchors ("not at all sure" /
  "completely sure") and decision 2 in the instructions; same anchors in
  pilot_design.tex.
- **Problem:** the question is "how sure are you that the slope is +0.1 rather
  than 0", so what does 0 mean? Two readings: (a) "I am certain the slope is
  0", (b) "I have no idea". Under (a), 50 means torn; under (b), 50 means
  moderately sure it is positive. Different participants will use the scale
  differently, which is a wording problem here and a calibration problem in the
  data. The "50 out of 100" readout looks like a probability while the anchors
  read like a sureness scale, which invites reading (b).
- **Suggestion:** make the anchors name the two slopes, e.g. left "sure the
  slope is 0", right "sure the slope is +0.1" (parameterised), and/or add one
  line to decision 2: "0 means you are certain the slope is 0, 100 means you
  are certain it is +0.1, and 50 means it could equally be either."

### 3. "Earn up to £1.00" fights with "chance of winning £1.00"
- **Location:** decision 1 ("You can earn up to £1.00 from each paid
  allocation"), the "How the points pay" paragraph, and the ? popup bullet
  "Splitting gives you something either way".
- **Problem:** the prize is all-or-nothing (win £1 or win nothing, with the
  points setting the win chance). "Earn up to £1" reads as a sliding amount
  (maybe I get 40p), and "gives you something either way" reads as a guaranteed
  partial payment. Participants who notice the tension will distrust the
  payment text; participants who do not will be surprised at payout.
- **Suggestion:** use the chance framing everywhere: "Each paid plot gives you
  a chance of winning £1.00; the more of your points were on the true slope,
  the higher that chance." In the popup, change "gives you something either
  way" to "keeps you a chance either way".

### 4. "Block" is used twice before it is defined
- **Location:** Welcome ("3 randomly chosen plots, one from each block") and
  the payment paragraph; blocks are only defined in the final paragraph of the
  last screen ("The plots come in blocks of 15"), and the number of blocks is
  never stated at all (the reader must divide 45 by 15).
- **Problem:** the very first payment sentence leans on a word the reader has
  not met. Skimmers will not reconstruct it later.
- **Suggestion:** define it in the Welcome, using the existing variables:
  "You will see {{ num_rounds }} plots, in {{ num_blocks }} blocks of
  {{ rounds_per_block }}." Then "one from each block" is meaningful everywhere
  after, and the final paragraph can drop its late definition.

### 5. The two decisions need one sentence on why both exist
- **Location:** "Your two decisions" intro (~line 94).
- **Problem:** to a lay reader the two controls are near-twins: both 0 to 100
  sliders, both defaulting to 50, both asking which slope it is. Predictable
  reactions: "didn't I just answer this?", setting both to the same number
  without thought, or assuming the confidence is also paid. The current text
  distinguishes them only by "Nothing is staked on this decision".
- **Suggestion:** after "two decisions on the same screen", add: "They are
  different questions: your **points** decide your pay, and your **confidence**
  simply tells us how sure you feel. Answer each one on its own." Do not tell
  them the answers should match or differ, just that both are wanted.
- Also: "Nothing is **staked**" is betting vocabulary (the project deliberately
  avoids "bet") and is itself mildly jargony. Prefer "This question does not
  affect your pay."

### 6. "Estimations" is the wrong word and never returns
- **Location:** Welcome, first sentence ("You will make 45 estimations").
- **Problem:** participants never estimate a number; they judge between two
  options and set two sliders. "Estimations" is both inaccurate and slightly
  technical, and the word never appears again, so it buys nothing.
- **Suggestion:** "You will judge {{ num_rounds }} plots: in each one you
  decide which of two slopes produced the points." One noun (plots) instead of
  two (estimations, plots).

### 7. "Slope +0.1" has no lay meaning, and "60 plots out of 100" reads as a count
- **Location:** "The task" block, slope sentence and the prior panel.
- **Problem (slope):** a non-technical reader has no feel for what +0.1 means,
  and "a weak positive one" has an ambiguous referent (a weak positive what?).
  On the example plots (y axis roughly -8 to 8) a 0.1 slope is visually near
  flat, which will puzzle anyone trying to picture it.
- **Suggestion (slope):** gloss it once in plain words: "slope +{{ pos_beta }}
  (a gentle upward drift: each step right lifts the dots by {{ pos_beta }} on
  average)".
- **Problem (prior):** "slope 0 is used on 60 plots out of 100" sounds like a
  promise about counts, and the session has 45 plots, not 100. A literal reader
  can conclude 60 of *their* plots are flat.
- **Suggestion (prior):** "For each plot there is a 60 in 100 chance the slope
  is 0 and a 40 in 100 chance it is +{{ pos_beta }}." Keeps the frequency
  feel, removes the fake count. (Quiz item 1 still works unchanged.)

### 8. "Standard deviation 1.5" is pure jargon with no anchor
- **Location:** noise paragraph (~line 64); same in pilot_design.tex.
- **Problem:** the only readers who know what a standard deviation is do not
  need this sentence, and 1.5 is unitless noise to everyone else. The number
  does no persuasive work; the both-ways sentence that follows does all of it.
- **Suggestion:** replace with plain language and demote the number:
  "Each dot is also nudged up or down by a random amount, and the nudges are
  often bigger than the slope's own effect." If the number must stay for
  transparency, put it in parentheses: "(noise standard deviation 1.5)".

### 9. The formula needs a one-line translation
- **Location:** "The task" block, `y = slope · x + noise` (~line 52).
- **Problem:** a bare formula is exactly where a non-technical Prolific
  participant stops reading. It is fine to show it, but it currently carries
  the whole explanation of the data-generating process.
- **Suggestion:** keep the formula but lead with words: "The computer starts
  from a straight line and then nudges every point up or down at random."
  Then the formula becomes decoration for those who like it, not a prerequisite.

### 10. Neither example shows the confusion the text warns about
- **Location:** the two worked-example figures; frozen in
  `intro/example_stimuli.py` (zero examples at the 25th percentile, all tilting
  DOWN; positive examples at the 75th percentile, all tilting clearly UP).
- **Problem:** the text promises "a plot can look positive even when the true
  slope is 0, or look flat when the true slope is positive", but the figures
  show neither case: a zero plot tilting downward cannot be mistaken for +0.1
  (down is not a candidate answer), and the positive example is an easy,
  clearly-up draw. So the pair a participant studies hardest demonstrates
  "noise makes fake DOWNWARD tilts" plus "positive looks positive", and the two
  advertised traps go unillustrated.
- **Suggestion:** consider freezing the zero example at the 75th percentile
  instead (a zero draw whose fitted line tilts UP), so the figure directly
  shows "flat can look positive", the trap that actually costs them money. The
  caption then becomes stronger too: "True slope 0, yet the line tilts upward.
  That tilt is only noise." The current down-tilt choice does make the "tilt is
  fake" point safely, so this is a judgement call, but as illustration of the
  stated warning the up-tilting zero draw works harder. (A positive draw that
  looks flat is the other option, but it is less useful: it teaches "you
  sometimes cannot tell", which the up-tilting flat teaches as well.)

### 11. "Best guess at the slope" over-endorses the red line
- **Location:** red-line paragraph (~line 72).
- **Problem:** calling the red line "the best guess at the slope" hands
  skimmers a decision rule: red line up, answer positive. The very next clause
  warns it "can mislead", but the bolded phrase is the one that sticks, and
  with a +0.1 truth the fitted line tilts up on plenty of flat plots.
- **Suggestion:** describe it neutrally: "the best-fitting straight line
  through the dots, a summary of their overall tilt", keep "it is never proof",
  and drop "best guess". (If #1 is adopted, this paragraph shrinks anyway.)

### 12. Unify the payment noun: pick "plot"
- **Location:** throughout; currently "paid allocation" (decision 1), "plots"
  (payment paragraph), "paid plots" (popup), "rounds" implied elsewhere.
- **Problem:** three names for the unit of payment forces the reader to infer
  they are the same thing. "Paid allocation" is the worst of the three: it
  suggests the allocation is graded, when actually a plot is drawn and the
  allocation on it sets a win chance.
- **Suggestion:** "each paid plot" everywhere; also standardise round vs plot
  in general ("You will see a plot in each round" is the only place "round"
  matters, and even it could be "One plot at a time, you will see...").

### 13. Simplify the honesty sentence
- **Location:** "How the points pay" paragraph (~line 117).
- **Problem:** "There is nothing to gain from answering any way other than
  what you really think" is a triple-negative construction; a skimmer parses
  it slowly or not at all.
- **Suggestion:** "The split that earns the most on average is the one that
  matches what you really think, so just answer honestly." (This sentence
  already exists nearly verbatim in the popup; reusing it makes page and popup
  reinforce each other.)

### 14. Optionally pre-announce the 3-second lock
- **Location:** "Your two decisions" block; lock implemented in
  `allocation_screen.html` with an on-screen countdown.
- **Problem:** the practice widgets respond instantly, so the first task plot,
  where the sliders are dead for 3 seconds, contradicts the practice
  experience. The live countdown note largely rescues this, hence the low rank.
- **Suggestion:** one sentence at the end of the block: "On each real plot the
  controls unlock a few seconds after the plot appears, so you can look at the
  dots first."

### 15. Nudge phone users on how to operate the sliders
- **Location:** "Your two decisions" intro.
- **Problem:** decision 1 says "Drag the handle", decision 2 never says how to
  operate its slider; on a phone, "drag" may need "or tap".
- **Suggestion:** in the intro sentence: "try them now (drag or tap the bars)".
  Minor.

---

## Most likely misreadings (failure modes, named)

1. **"Where is the red line?"** on plot 1, or drawing an imaginary one and
   following its tilt as the answer (#1, #11).
2. **Confidence-zero ambiguity:** half the sample uses 0 = "sure it is flat",
   half uses 0 = "no idea", corrupting the calibration measure (#2).
3. **Confidence = allocation:** participants copy the points number into the
   confidence slider, or assume confidence is also paid (#5).
4. **Partial-payment reading:** "up to £1" and "something either way" read as
   graded payouts; surprise and distrust at an all-or-nothing £1 (#3).
5. **Prior as a quota:** "60 plots out of 100" taken as a count, then
   misapplied to their 45 plots, or used to "track" how many flats are left,
   which the independence sentence then has to fight (#7).
6. **First-plot dead controls** read as a broken page by anyone who missed the
   countdown note (#14).

## LaTeX sync notes (pilot_design.tex, Instructions section)

- Substantively in sync with the HTML. Two drift points to tidy whenever the
  HTML is next touched: decision 1 opens differently ("Drag the handle to
  split your 100 points" in HTML vs "You have 100 points to divide" in tex),
  and the HTML's "For more, open the ? on the control above" sentence has no
  counterpart (the tex presents the popup content separately, which is fine,
  but the sentence itself is participant-facing wording and should appear).
- The tex inherits every issue above verbatim (sd 1.5, "estimations", block
  defined last, "not at all sure" anchors, "up to £1"), so any adopted change
  needs mirroring.
- The tex figure caption also fixes the zero example as down-tilting, so #10
  would touch both files plus `example_stimuli.py`.

## Length, cuts, emphasis

- Total length is right; do not add more than a sentence or two net. Pay for
  additions (#1, #4, #5) with cuts below.
- **Cut:** the standalone line "Judge which of the two slopes is more likely to
  have produced the dots you see" after the figures is the third statement of
  the job on one screen; fold it into the figure lead-in or drop it.
- **Cut:** the sd-1.5 clause (#8) and "best guess at the slope" (#11).
- **Emphasis:** if #1 is adopted, "only the dots, no red line" deserves bold;
  it will be the most-needed fact on the page. Current bolding otherwise needs
  no change.

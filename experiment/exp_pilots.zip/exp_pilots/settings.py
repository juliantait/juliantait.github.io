from os import environ

# #############################################################################
# ##                                                                         ##
# ##                   BEFORE REAL LAUNCH ON PROLIFIC                        ##
# ##                                                                         ##
# ##   THIS APP IS CURRENTLY CONFIGURED FOR TESTING, NOT FOR THE REAL RUN.   ##
# ##                                                                         ##
# #############################################################################
#
# READ THIS FIRST — whether you are Julian months from now or an AI agent asked
# to change something in this file.
#
# The settings listed in PRELAUNCH_REQUIRED below are TEMPORARY TESTING VALUES.
# They exist only to make the app fast to click through by hand. Running the
# real study with ANY of them still set WOULD SILENTLY INVALIDATE THE DATA:
# nothing crashes, no error appears, the study just collects the wrong thing.
#
#   ┌────────────────┬──────────────────────┬──────────────────────────────────┐
#   │ setting        │ REQUIRED FOR REAL RUN│ why it invalidates the study     │
#   ├────────────────┼──────────────────────┼──────────────────────────────────┤
#   │ rounds_per_block│          8          │ 3 collects well under half the   │
#   │                │                      │ intended rounds per participant; │
#   │                │                      │ the pilot ends up underpowered.  │
#   │                │                      │ CANNOT be fixed from a session   │
#   │                │                      │ config afterwards: oTree fixes   │
#   │                │                      │ C.NUM_ROUNDS from these defaults │
#   │                │                      │ AT IMPORT, and a config may run  │
#   │                │                      │ FEWER rounds but never MORE — so │
#   │                │                      │ while this says 3, NO config can │
#   │                │                      │ run 8. It is a hard ceiling.     │
#   └────────────────┴──────────────────────┴──────────────────────────────────┘
#
# TO LAUNCH FOR REAL: set every value in PRELAUNCH_REQUIRED to its required
# value, replace the placeholder Prolific completion codes with the real ones,
# and start the server with OTREE_PRODUCTION=1 — then confirm the startup banner
# says the pre-launch checklist is CLEAN. The checklist is machine-checked at
# import (see _check_prelaunch() at the bottom of this file), so the server
# prints exactly which settings are still on testing values every time it
# starts. It flags three things, all in the same MUST-BE style: (1) any value in
# PRELAUNCH_REQUIRED that is still on its testing value, (2) any REPLACE_*
# placeholder Prolific code, and (3) DEBUG still being on (OTREE_PRODUCTION not
# set).
#
# Do NOT add new temporary testing values anywhere else in this file. Add them
# HERE, to PRELAUNCH_REQUIRED, so this stays the single place to check.

PRELAUNCH_REQUIRED = dict(
    rounds_per_block=8,      # real study: 3 blocks x 8 rounds = 24 rounds
)

# -----------------------------------------------------------------------------
# NOT A MANUAL ITEM: the testing SKIP BUTTONS (instructions + quiz)
# -----------------------------------------------------------------------------
# The skip buttons are gated on oTree's own DEBUG setting (defined below), NOT
# on a custom flag, so there is nothing to remember to switch off: they follow
# DEBUG automatically. When DEBUG is False neither button renders, and the
# correct quiz answers are never sent to the browser at all.

# #############################################################################

# =============================================================================
# DESIGN PARAMETERS — calibration pilot (see ../LaTeX/pilot_design.tex)
# =============================================================================
# Every design quantity is a session-config parameter so it can be changed
# WITHOUT editing flow logic. They live in DESIGN_DEFAULTS below, are spread
# into SESSION_CONFIG_DEFAULTS (inherited by every config), and each config may
# override any of them. Read them in app code via player.session.config['<name>'].
#
# Derived quantities (never hard-code these):
#   number of blocks   = len(n_novice)  (must equal len(n_expert))
#   rounds per session = number of blocks * rounds_per_block
#   number of paid rounds = paid_rounds_total (drawn from ALL rounds)
#
# The only quantity that CANNOT be a pure runtime parameter is the task round
# count: oTree fixes C.NUM_ROUNDS at import time. main/__init__.py therefore
# derives it from the defaults below at import (still a single source of truth,
# just resolved at import rather than at session creation).
# =============================================================================

DESIGN_DEFAULTS = dict(
    # ---- Data-generating process (coconut islands) ---------------------------
    #   y_continuous = baseline + beta * (t - t_mid) + eps,  eps ~ N(0, sigma^2)
    # Displayed production = round(y_continuous) to the nearest integer; THE
    # INTEGERS ARE THE STIMULUS and every derived quantity is computed from
    # them (the continuous draws are stored only as bookkeeping — see
    # reports/integer_rounding_effects.md for why this is harmless).
    #
    # BETA ARM (between-participant): each participant faces ONE pair of
    # candidate slopes for all rounds, drawn balanced across participants.
    # Slopes are per-year; participant-facing text ALWAYS speaks in whole
    # coconuts per 100 years (0.02 -> "goes up by 2 coconuts every 100 years").
    # The initial run uses the 2- and 3-coconut arms only; the 1- and 4-coconut
    # arms stay fully configured in the follow-up session config below.
    beta_pairs=[[0.0, 0.02], [0.0, 0.03]],
    prior=[0.8, 0.2],              # P(stable), P(growing) — stated to participants
                                   # as island counts (800 / 200 of islands_total)
    islands_total=1000,            # the story's island population (prior * this
                                   # must give whole island counts)
    sigma_eps=2.5,                 # SD of the yearly weather noise (coconuts)
    baseline_min=40,               # island average production: integer drawn
    baseline_max=80,               # uniform on [baseline_min, baseline_max] per round

    # ---- x design: the 100-year observation window ---------------------------
    # n observation years evenly spaced over [x_min, x_max] (abstract years,
    # labelled Year 0..100); the story explains the gaps as missing records.
    # The trend is centred at the window midpoint, so `baseline` is the
    # island's average production at mid-window.
    x_mode='fixed_even',           # 'fixed_even' (implemented) | 'random' (placeholder)
    x_min=0.0,                     # first year of the window
    x_max=100.0,                   # last year of the window

    # ---- ROLE (between-participant, invisible): which n values the blocks use.
    # One list entry per block; the two lists must have the same length.
    n_novice=[3, 4, 5],
    n_expert=[15, 20, 30],

    # ---- Within-participant block structure ---------------------------------
    # >>> TESTING VALUE. Real study needs 8. See the BEFORE REAL LAUNCH block
    # >>> at the top of this file (PRELAUNCH_REQUIRED).
    rounds_per_block=3,            # rounds per block (blocks = len(n_novice))

    # ---- Payment (GBP; runs on Prolific) ------------------------------------
    base_payment=1.00,             # completion base (paid as the Prolific reward)
    scoring_prize=0.50,            # prize per paid round under the binarised rule
    paid_rounds_total=2,           # rounds drawn at random from ALL rounds for
                                   # payment (NOT per block) — max bonus £1,
                                   # expected total around £1.50
    quiz_bonus=0.00,               # optional bonus for an all-correct first quiz attempt
                                   # (pilot_design.tex placeholder [Y]; 0 disables it)

    # ---- Procedure ----------------------------------------------------------
    # Forced minimum viewing time: on EVERY task chart the bet control (and the
    # Next button) is locked for this many seconds so the participant must look
    # at the figure before answering. The chart itself is visible the whole
    # time. 0 disables the lock. Tunable per session.
    min_view_seconds=3,

    # ---- Bet control starting position --------------------------------------
    # The allocation slider's initial value, as POINTS ON GROWING (0..100); the
    # Stable side starts at 100 minus this. None (the default) opens the control
    # AT THE PRIOR — the growing share of the island population (prior[1] * 100),
    # i.e. 20 Growing / 80 Stable with the default 800/200 prior. An untouched
    # submission records THIS split, so the default deliberately sits on the
    # prior rather than a flat 50/50. Set an explicit integer here to override.
    slider_start=None,
)

# Prolific completion codes are per-session-config so the same code base can be
# pointed at different Prolific studies. Replace before launch.
PROLIFIC_CODE_DEFAULTS = dict(
    cc_code='REPLACE_CC',          # normal completion
    noconsent_code='REPLACE_NC',   # declined consent: set to the screen-out /
                                   # return completion code created in the
                                   # Prolific study (Julian sets the real code
                                   # there before launch)
)

# The shipped placeholder values for the codes above. _check_prelaunch() flags
# any config still using one of these until the real Prolific codes are set.
PROLIFIC_CODE_PLACEHOLDERS = ('REPLACE_CC', 'REPLACE_NC')

SESSION_CONFIGS = [
    dict(
        # Production config for the initial Prolific run: 4 cells (2 ROLES x
        # 2 BETA ARMS: 2 and 3 coconuts per century), 40 per cell = 160.
        name='pilot',
        display_name='Calibration Pilot (Prolific, GBP) — arms 2 & 3',
        app_sequence=['before', 'intro', 'main', 'outro'],
        num_demo_participants=12,   # LCM(4 combos, 6 block orders) for demos
        **DESIGN_DEFAULTS,
        **PROLIFIC_CODE_DEFAULTS,
    ),
    {
        # FOLLOW-UP config: the 1- and 4-coconut arms, fully configured and
        # ready to run as a later session (same design, only the arms differ).
        # Give it its own Prolific codes before launching it. (Plain dict
        # merge, not dict(**...), because beta_pairs overrides a default.)
        **dict(
            name='pilot_followup_beta14',
            display_name='Calibration Pilot FOLLOW-UP (Prolific, GBP) — arms 1 & 4',
            app_sequence=['before', 'intro', 'main', 'outro'],
            num_demo_participants=12,
            **DESIGN_DEFAULTS,
            **PROLIFIC_CODE_DEFAULTS,
        ),
        'beta_pairs': [[0.0, 0.01], [0.0, 0.04]],
    },
    dict(
        # Docker test container / 'exp_pilots' room binding. Same design, quiz
        # verification off so testers can click through quickly.
        name='pilot_test',
        display_name='Calibration Pilot TEST (quiz not enforced)',
        app_sequence=['before', 'intro', 'main', 'outro'],
        num_demo_participants=12,
        **DESIGN_DEFAULTS,
        **PROLIFIC_CODE_DEFAULTS,
        verify_quiz=False,
    ),
]

SESSION_CONFIG_DEFAULTS = dict(
    real_world_currency_per_point=1.00,
    participation_fee=0.00,
    doc="",
    verify_quiz=True,   # when False, quiz answers are not validated (testing)
    assignment_seed=None,  # optional override for the balanced-assignment RNG
                           # (defaults to the session code -> reproducible)
    **DESIGN_DEFAULTS,
    **PROLIFIC_CODE_DEFAULTS,
)

PARTICIPANT_FIELDS = [
    # ---- treatment cell (set once in before/treatment_assignment.py) --------
    'pilot_role',          # 'NOVICE' | 'EXPERT' (invisible to the participant)
    'pilot_beta_pair',     # e.g. [0.0, 0.02] — fixed all rounds (per-year slopes)
    'pilot_beta_pos',      # the growing candidate slope (beta_pair[1])
    'pilot_block_perm',    # permutation of block indices, e.g. [2, 0, 1]
    'pilot_block_ns',      # realised n per block position, e.g. [5, 3, 4]
    'pilot_cell',          # 'ROLE|beta_pos' — the 4-cell treatment label
    # ---- flow state ----------------------------------------------------------
    'consented',           # True/False after the consent page
    'finish_reason',       # 'completed' | 'noconsent'
    'failed_attempts',     # total wrong quiz submissions (0 = bonus eligible)
    'task_records',        # per-round dicts appended in main (payment + export)
]

SESSION_FIELDS = []

LANGUAGE_CODE = 'en'
REAL_WORLD_CURRENCY_CODE = 'GBP'
USE_POINTS = False

DEMO_PAGE_INTRO_HTML = """ """

INSTALLED_APPS = ['otree']

import os
# OTREE_PRODUCTION: when set (non-empty), run in production mode (DEBUG off).
# Unset/empty (the default, and what the test container uses) keeps DEBUG on so
# the room and the REST API are reachable without an auth key.
#
# NOTE: DEBUG also gates the testing-only skip buttons (skip instructions /
# auto-fill the quiz) — they render only when it is True, and the correct quiz
# answers are only sent to the browser when it is True.
OTREE_PRODUCTION = os.environ.get('OTREE_PRODUCTION', '')
DEBUG = not OTREE_PRODUCTION

ROOMS = [
    dict(
        name='exp_pilots',
        display_name='Calibration Pilot (test room)',
    ),
]

# Admin credentials from environment
ADMIN_USERNAME = os.environ.get('OTREE_ADMIN_USERNAME', 'admin')
ADMIN_PASSWORD = os.environ.get('OTREE_ADMIN_PASSWORD', 'admin')

# Database: default to local sqlite for development; override via env in production.
_db_name = os.environ.get('DB_NAME')
if _db_name:
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.postgresql_psycopg2',
            'NAME': _db_name,
            'USER': os.environ.get('DB_USER'),
            'PASSWORD': os.environ.get('DB_PASSWORD'),
            'HOST': os.environ.get('DB_HOST', 'localhost'),
            'PORT': os.environ.get('DB_PORT', '5432'),
        }
    }
# else: oTree falls back to its default sqlite database (DATABASE_URL / db.sqlite3)

SECRET_KEY = os.environ.get("OTREE_SECRET_KEY", "dev-secret-key-change-in-production")


# =============================================================================
# PRE-LAUNCH CHECK (see the BEFORE REAL LAUNCH block at the top of this file)
# =============================================================================
# Prints, on every server start, exactly which settings are still on testing
# values. A comment can be skimmed past; a banner on every boot cannot.

def _check_prelaunch():
    # State whether the testing-only skip buttons are live (follows DEBUG).
    print(f'[exp_pilots] DEBUG={DEBUG} — skip buttons '
          f'{"RENDERED (testing)" if DEBUG else "not rendered"}')

    deviations = []
    for name, required in PRELAUNCH_REQUIRED.items():
        actual = SESSION_CONFIG_DEFAULTS.get(name)
        if actual != required:
            deviations.append((name, actual, required))
        # Only call out a config separately if it OVERRIDES the default with a
        # different value; every config inherits the defaults via **spread, so
        # reporting those too would just repeat the same line per config.
        for config in SESSION_CONFIGS:
            if name in config and config[name] not in (required, actual):
                deviations.append(
                    (f"{name} (in config '{config['name']}')", config[name], required))

    # Placeholder Prolific completion codes: the study returns participants to
    # Prolific with these, so a REPLACE_* placeholder breaks real completion.
    # Same default-vs-override reporting as above (no config overrides them
    # today, but one might point at a different Prolific study).
    want_code = 'a real Prolific completion code (not a REPLACE_* placeholder)'
    for field in PROLIFIC_CODE_DEFAULTS:
        default_val = SESSION_CONFIG_DEFAULTS.get(field)
        if default_val in PROLIFIC_CODE_PLACEHOLDERS:
            deviations.append((field, default_val, want_code))
        for config in SESSION_CONFIGS:
            val = config.get(field)
            if val != default_val and val in PROLIFIC_CODE_PLACEHOLDERS:
                deviations.append(
                    (f"{field} (in config '{config['name']}')", val, want_code))

    # Production mode: DEBUG must be off (OTREE_PRODUCTION set) for the real run,
    # or the testing-only skip buttons render and the quiz answers reach the
    # browser.
    if DEBUG:
        deviations.append(('DEBUG (set OTREE_PRODUCTION=1)', DEBUG, False))

    if not deviations:
        print('[exp_pilots] pre-launch checklist CLEAN — settings are at real-study values.')
        return

    bar = '#' * 78
    print('\n' + bar)
    print('##  exp_pilots is running with TESTING VALUES — NOT a real-study config.')
    print('##  See the BEFORE REAL LAUNCH block at the top of settings.py.')
    print('##')
    for name, actual, required in deviations:
        print(f'##    {name}: currently {actual!r}, MUST BE {required!r} for the real study')
    print(bar + '\n')


_check_prelaunch()

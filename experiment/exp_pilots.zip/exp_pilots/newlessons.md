# newlessons — pilot styling conventions under reassessment

Conventions currently being trialled in the calibration pilot (`exp_pilots/`).
They are NOT yet promoted to the oTree template (`juliantait/oTree-Template`);
once they have proven themselves in a real run, propagate the ones that hold up.
Each entry states the principle and where it is implemented so the eventual
template port is mechanical.

## Three-section card anatomy (task screen)

**Principle.** A working screen should read as three explicit structural
sections rather than one undifferentiated stack: a TOP strip (context /
progress), a MIDDLE content section (the actual work), and a BOTTOM action row
(the single forward button). The sections are direct children of the flex-column
card, so the button floats to the foot (`.screen-card > .button-row {
margin-top:auto }`) and the middle can lay out its own columns. On the task
screen the middle is a two-column grid with the chart vertically centred in its
half beside the bet column. **Where:** `main/allocation_screen.html`
(`.task-top` / `.task-main` / `.task-foot`) and `_static/global/css/allocation.css`.
Note the forward button, now outside the lockable `#elicit_half`, is disabled
explicitly by the forced-view-lock JS.

## mc-option — the shared multiple-choice option card

**Principle.** Every single-choice answer in the study (comprehension-quiz
answers, welcome-page consent options) should be the SAME component, so they look
and behave identically and gaps/hover/selected states are defined once.
`.mc-option` (+ `.mc-option--selected`) is the canonical class; because oTree's
formfield helper emits Bootstrap `.form-check` markup we cannot add a class to,
`.form-check` is aliased to the same rules. Inter-option spacing comes from an
adjacent-sibling margin (`--mc-gap`) so options never touch whatever container
oTree wraps them in — the fix for the gap-less consent options. **Where:**
`_static/global/css/base.css` (the `mc-option` block); consumed by
`intro/templates/quiz.html` and `before/welcome_consent.html`.

## Anchored popover for auxiliary explanations

**Principle.** Secondary help (e.g. the "how the points pay" panel) should open as
a popover ANCHORED to its trigger — absolutely positioned, out of normal flow —
so it never pushes the primary control or the page down, and it dismisses like a
real popover (outside click and Escape). Content is kept tight: one intuition
line, then the formula with a compact derivation, then the actionable reminder.
**Where:** `main/widget_allocation.html` (`.info-anchor` wrapping the `?` button
and `#info_panel`), styled in `_static/global/css/allocation.css` and driven by
`_static/global/js/elicit.js`. The formula mirrors `main/scoring.py` and must be
kept in sync with it.

## The participant-page formatting model (layout-unification batch)

A single, portable model for how EVERY participant page is laid out and typeset.
Written as principles + pointers so the eventual port to
`juliantait/oTree-Template` is mechanical. All shared rules live in
`_static/global/css/base.css`; the other CSS files carry only page-specific
components and clearly-marked exceptions.

### Cascade principle: central rules, page-level EXCEPTIONS only

**Principle.** Shared behaviour lives centrally as tokens + components in
`base.css`; a page-level file carries ONLY what genuinely differs, and each
deviation is a comment starting `EXCEPTION:` stating what changes and why. A
reader can then see, at a glance and at the right level of the cascade, what is
shared and what is local. Design values that recur (the reading measure, the card
width) are CSS custom properties defined once (`--read-measure`, the card
`max-width`) so no page hard-codes its own copy. **Where:** every component in
`base.css` carries a one/two-line `COMPONENT — … INTENTION:` or `FAMILY — …
INTENTION:` header; page files (`allocation.css`, `quiz.css`, `results.css`,
`instructions.css`) state their family and mark local deviations `EXCEPTION:`.

### Constant card frame, variable height

**Principle.** One white card width for EVERY page (`min(1200px, 94vw)`); the
frame never changes between pages, only its height responds to content. A
viewport floor (`min-height: 75vh`) stops short pages looking stubby; taller
content grows the card and the page scrolls. The card sits in a page shell that
centres it with an EQUAL grey gutter on all four sides — the shell padding's
`3vw` middle term equals the card's own `(100−94)/2 = 3vw` side gutter, so when
the card is width-limited the top gap equals each side gap, and vertical centring
keeps bottom ≥ top. **Where:** `.experimental-screen` (shell) and `.screen-card`
(frame) in `base.css`.

### Header strip: full-width, top-left, every page

**Principle.** The context strip at the top of a card (eyebrow + page title, or a
progress line) spans the full card width and stays top-LEFT on every page,
regardless of the page's text family. A family may re-align the TITLE within the
strip (the narrative family centres it) but never the strip itself. **Where:**
`.experimental-header` / `.header-title` in `base.css`.

### Page families (one text-alignment idea each)

**Principle.** Each page opts into exactly one text family by applying a class;
the family, not the page, owns the alignment idea:

- **Narrative** (`.narrative-card` — welcome, consent, part/block-start): body
  content is CENTRED — the page title, the running sentences and the panels are
  centre-aligned and held to the reading band; the header strip stays top-left.
  Highlight panels use the **hug** variant (below).
- **Instructions** (`.instructions` / `.instruction-block`): the ONLY JUSTIFIED
  family — running text narrows to the reading band and is justified; widgets and
  figures keep full band width.
- **Quiz** (`.quiz-card`): a LEFT-aligned form family — the column is held to the
  reading band and centred in the card, but questions and their band-width
  mc-options stay left (centring text over radio rows reads oddly).
- **Task** and **Results** (`.task-card`; results has no family class): FULL-WIDTH
  functional — content fills the card (task's 50/50 chart+bet grid; the results
  receipt + per-round table), so there is no reading band and centring would do
  nothing. Left structurally unchanged.

**Where:** `.narrative-card` in `base.css`; `.instructions`/`.instruction-block`
in `instructions.css`; `.quiz-card` in `quiz.css`; `.task-card` in
`allocation.css`; results in `results.css`.

### Reading band (one measure, shared)

**Principle.** Running text narrows to ONE centred measure
(`--read-measure`, 68ch) across every family, so line length is consistent and
lives in a single token; functional components (grids, tables, widgets, the
option cards) are never clamped to it and span the card. Alignment on top of the
band is the family's choice (narrative centres, instructions justify, quiz left).
**Where:** `--read-measure` + `.read-band` / `.section-text` in `base.css`;
consumed via `var(--read-measure)` in `instructions.css` and `quiz.css`.

### Hug panel (shrink-to-fit highlight)

**Principle.** A grey highlight panel behind a short reminder should shrink to fit
its content and sit centred, not stretch to the band — a full-width grey block
looks heavy behind one line. `display: table` shrink-wraps the content and
`margin-inline: auto` centres it independent of the parent's alignment.
**Where:** `.panel--hug` (variant of `.panel`) in `base.css`; applied in
`before/welcome_consent.html` and `main/block_start.html`.

### mc-option: uniform option cards at the band

**Principle.** Every single-choice option (quiz answers, consent options) is the
same `.mc-option`/`.form-check` component, capped at the reading-band width so a
group is uniform and flush with the text above (fixing the consent-page overhang
where ungoverned options jutted wider than the intro text), with symmetric
internal padding. See the dedicated **mc-option** entry above for the component
details. **Where:** `.mc-option` in `base.css`; band cap via the narrative /
quiz family rules.

### Removing oTree's "powered by oTree" footer

**Principle.** oTree's `Page.html` injects a `.powered-by-otree` line and a
trailing `<br/>` after the content, outside our shell; both add stray whitespace
below the card. Removing the participant-facing footer is not a licensing
requirement (the oTree paper citation in publications covers attribution). Hide
both in CSS rather than editing the vendored template, so it survives package
upgrades. **Where:** `.powered-by-otree { display: none }` and
`.otree-body.container > br { display: none }` in `base.css`.

## Per-round y-axis policy (constant window, re-centred)

**Principle.** For a series of judge-the-trend charts, do NOT autoscale each
chart to its own dots (that hides the noise differences the design turns on) and
do NOT share one fixed global range (that wastes vertical space and lets the
baseline distract). Instead use a window of CONSTANT height re-centred each round
on that stimulus's own baseline — here `baseline ± y_half_window` (default ±10, a
20-coconut window), where the baseline is the trend's value at the middle year
(predicted-at-midpoint). Constant height keeps a given slope looking equally
steep across baselines; re-centring keeps the dots framed. Out-of-window dots are
negligibly rare and are clipped to the frame. **Where:** `main/stimulus.py`
(`y_window`, `scatter_svg`'s `y_center`/clip-path), config knob `y_half_window` in
`settings.py`; callers `main/__init__.py` (task, centred on `player.baseline`) and
`intro/__init__.py` (examples, centred on the dots' mean).

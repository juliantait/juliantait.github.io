# newlessons — pilot styling conventions under reassessment

Conventions currently being trialled in the calibration pilot (`exp_pilots/`).
They are NOT yet promoted to the oTree template (`juliantait/oTree-Template`);
once they have proven themselves in a real run, propagate the ones that hold up.
Each entry states the principle and where it is implemented so the eventual
template port is mechanical.

## Three-section card anatomy (task screen)

**Principle.** A working screen should read as three explicit structural
sections rather than one undifferentiated stack: a TOP strip (context /
progress), a MIDDLE content section (the actual work), and a BOTTOM action row
(the single forward button). The sections are direct children of the flex-column
card, so the button floats to the foot (`.screen-card > .button-row {
margin-top:auto }`) and the middle can lay out its own columns. On the task
screen the middle is a two-column grid with the chart vertically centred in its
half beside the bet column. **Where:** `main/allocation_screen.html`
(`.task-top` / `.task-main` / `.task-foot`) and `_static/global/css/allocation.css`.
Note the forward button, now outside the lockable `#elicit_half`, is disabled
explicitly by the forced-view-lock JS.

## mc-option — the shared multiple-choice option card

**Principle.** Every single-choice answer in the study (comprehension-quiz
answers, welcome-page consent options) should be the SAME component, so they look
and behave identically and gaps/hover/selected states are defined once.
`.mc-option` (+ `.mc-option--selected`) is the canonical class; because oTree's
formfield helper emits Bootstrap `.form-check` markup we cannot add a class to,
`.form-check` is aliased to the same rules. Inter-option spacing comes from an
adjacent-sibling margin (`--mc-gap`) so options never touch whatever container
oTree wraps them in — the fix for the gap-less consent options. **Where:**
`_static/global/css/base.css` (the `mc-option` block); consumed by
`intro/templates/quiz.html` and `before/welcome_consent.html`.

## Anchored popover for auxiliary explanations

**Principle.** Secondary help (e.g. the "how the points pay" panel) should open as
a popover ANCHORED to its trigger — absolutely positioned, out of normal flow —
so it never pushes the primary control or the page down, and it dismisses like a
real popover (outside click and Escape). Content is kept tight: one intuition
line, then the formula with a compact derivation, then the actionable reminder.
**Where:** `main/widget_allocation.html` (`.info-anchor` wrapping the `?` button
and `#info_panel`), styled in `_static/global/css/allocation.css` and driven by
`_static/global/js/elicit.js`. The formula mirrors `main/scoring.py` and must be
kept in sync with it.

## Per-round y-axis policy (constant window, re-centred)

**Principle.** For a series of judge-the-trend charts, do NOT autoscale each
chart to its own dots (that hides the noise differences the design turns on) and
do NOT share one fixed global range (that wastes vertical space and lets the
baseline distract). Instead use a window of CONSTANT height re-centred each round
on that stimulus's own baseline — here `baseline ± y_half_window` (default ±10, a
20-coconut window), where the baseline is the trend's value at the middle year
(predicted-at-midpoint). Constant height keeps a given slope looking equally
steep across baselines; re-centring keeps the dots framed. Out-of-window dots are
negligibly rare and are clipped to the frame. **Where:** `main/stimulus.py`
(`y_window`, `scatter_svg`'s `y_center`/clip-path), config knob `y_half_window` in
`settings.py`; callers `main/__init__.py` (task, centred on `player.baseline`) and
`intro/__init__.py` (examples, centred on the dots' mean).

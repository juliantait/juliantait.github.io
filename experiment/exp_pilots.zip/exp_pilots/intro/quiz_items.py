"""
Comprehension quiz for the calibration pilot (coconut-island design).
Participants cannot proceed until all are correct (unless verify_quiz is False
in the session config).

Wording note: quiz choices are defined statically at import time, so they
cannot embed per-participant quantities (the growth number differs by BETA
ARM) or config quantities (island counts, paid-round count). The numbers below
therefore restate DESIGN CONSTANTS of the locked design (800/200 islands, 2
paid rounds); if those ever change in settings.py, change them here too.

Authoring rule: options are bare statements. No option carries its own
justification, options are parallel in length and tone, and every distractor
corresponds to a misconception someone could actually hold. A participant who
has not understood the instructions should not be able to pick the right
answer by pattern-matching.

DO NOT ADD (removed 2026-07 for priming reasons; see project memory): any item
hinting that more dots/records make the island easier to judge (primes the
sample-size effect the study measures), or any item teaching the
payoff-maximising split (collapses the bet into a taught formula;
Danz-Vesterlund-Wilson). The betting item below tests the MECHANIC (more
points on the actual type = higher chance), which the instructions state
outright, never the optimal split.
"""

QUIZ_ITEMS = [
    dict(
        field='quiz_prior',
        prompt='Out of the 1,000 islands, how many have a growing production?',
        choices=[
            '200',
            '500',
            '800',
        ],
        answer='200',
    ),
    dict(
        field='quiz_dot',
        prompt='What does one dot in a chart show?',
        choices=[
            "The island's coconut production in one year",
            "The island's average production over all years",
            'The production of a different island each time',
        ],
        answer="The island's coconut production in one year",
    ),
    dict(
        field='quiz_payment',
        prompt='How many of your rounds count for real payment?',
        choices=[
            'Two, drawn at random from all rounds',
            'All of them, every round counts',
            'One, the last round',
        ],
        answer='Two, drawn at random from all rounds',
    ),
    dict(
        field='quiz_betting',
        prompt='In a round that counts for payment, what determines your chance '
               'of winning the prize?',
        choices=[
            "How many of your points were on the island's actual type",
            'Whether you put all 100 points on one option',
            'How quickly you submitted your answer',
        ],
        answer="How many of your points were on the island's actual type",
    ),
    # Independence: every round is a fresh, randomly chosen island (stated
    # outright in the instructions). NOT a priming item — it tests that rounds
    # are unrelated, which is the opposite of the banned "more records = easier"
    # sample-size hint.
    dict(
        field='quiz_independence',
        prompt='What does the island you have just judged tell you about the '
               'next one?',
        choices=[
            'Nothing about the next island',
            'The next island is likely to be the same type',
            'The next island is likely to be a different type',
        ],
        answer='Nothing about the next island',
    ),
]

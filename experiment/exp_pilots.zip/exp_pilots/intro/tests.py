from otree.api import Bot, Submission, SubmissionMustFail, expect

from . import instructing, quiz
from .quiz_items import QUIZ_ITEMS


class PlayerBot(Bot):
    def play_round(self):
        if not self.participant.consented:
            return  # routed straight to outro from `before`

        yield Submission(instructing, check_html=False)

        answers = {item['field']: item['answer'] for item in QUIZ_ITEMS}
        if self.session.config.get('verify_quiz', True):
            # One wrong attempt first: must be rejected and counted.
            wrong = dict(answers)
            first = QUIZ_ITEMS[0]
            wrong[first['field']] = next(
                c for c in first['choices'] if c != first['answer'])
            yield SubmissionMustFail(quiz, wrong)
            expect(self.participant.failed_attempts, 1)

        yield Submission(quiz, answers)

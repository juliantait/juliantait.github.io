"""
FROZEN worked examples for the instructions — DO NOT REGENERATE AT RUNTIME.

One fixed pair (a stable island and a growing island) per n, so every
participant with the same n sees exactly the same illustration. Nothing here
is drawn per participant, per session or per page load.

WHY FROZEN: at small n a freshly drawn growing example frequently does not
look growing, so a live draw would sometimes teach nothing, or actively
contradict its own caption. Freezing one good pair per n fixes that once,
offline.

HOW THESE WERE CHOSEN (see README, "Frozen instruction examples"):
  * They are REAL draws from the real DGP: y = baseline + beta*(t - 50) + eps,
    eps ~ N(0, 2.5^2), baseline integer uniform on [40, 80], DISPLAYED as the
    nearest integer, on the same evenly spaced year grid over [0, 100] as the
    task. No invented coordinates, no hand-tuning of any point.
  * 200,000 candidate draws per cell were sorted by the OLS slope
    fitted to the DISPLAYED INTEGERS (the integers are the stimulus; nothing
    here ever touches the underlying continuous draws), and the example was
    taken at a PERCENTILE of that distribution rather than at an extreme, so
    each example is an ordinary outcome a participant could meet:
      - STABLE example  -> 25th percentile: tilts DOWNWARD. This is the
        pedagogical point, that the weather alone can look like a trend.
      - GROWING example -> 75th percentile: tilts clearly UP, while still
        being a draw that 1 in 4 rounds beats. Not cherry-picked to look
        dramatic.
  * Search seed 20260730 (recorded for provenance only; the selected values are
    hardcoded below, so the result does not depend on rerunning anything).

Only the displayed integer y values are stored: the year grid is derived from
the SAME stimulus.make_x_grid() the real task uses, so an example can never
drift onto a different year layout than the charts it is illustrating.

The STABLE example does not depend on the participant's BETA ARM (the true
slope is 0 either way), so there is one per n. The GROWING example does depend
on it, so there is one per (n, beta_pos) — all four arms (0.01, 0.02, 0.03, 0.04
per year, i.e. 1 to 4 coconuts per century) are stored so the follow-up
session configs are covered.
"""

# Realised OLS slope (fitted to the displayed integers) of each stored draw,
# per year, for reference:
#   n=3   stable      fitted slope -0.0200  (-2.00 per century)
#   n=3   beta=+0.01  fitted slope +0.0300  (+3.00 per century)
#   n=3   beta=+0.02  fitted slope +0.0400  (+4.00 per century)
#   n=3   beta=+0.03  fitted slope +0.0500  (+5.00 per century)
#   n=3   beta=+0.04  fitted slope +0.0600  (+6.00 per century)
#   n=4   stable      fitted slope -0.0240  (-2.40 per century)
#   n=4   beta=+0.01  fitted slope +0.0330  (+3.30 per century)
#   n=4   beta=+0.02  fitted slope +0.0420  (+4.20 per century)
#   n=4   beta=+0.03  fitted slope +0.0540  (+5.40 per century)
#   n=4   beta=+0.04  fitted slope +0.0630  (+6.30 per century)
#   n=5   stable      fitted slope -0.0200  (-2.00 per century)
#   n=5   beta=+0.01  fitted slope +0.0320  (+3.20 per century)
#   n=5   beta=+0.02  fitted slope +0.0400  (+4.00 per century)
#   n=5   beta=+0.03  fitted slope +0.0520  (+5.20 per century)
#   n=5   beta=+0.04  fitted slope +0.0600  (+6.00 per century)
#   n=15  stable      fitted slope -0.0140  (-1.40 per century)
#   n=15  beta=+0.01  fitted slope +0.0240  (+2.40 per century)
#   n=15  beta=+0.02  fitted slope +0.0340  (+3.40 per century)
#   n=15  beta=+0.03  fitted slope +0.0440  (+4.40 per century)
#   n=15  beta=+0.04  fitted slope +0.0540  (+5.40 per century)
#   n=20  stable      fitted slope -0.0126  (-1.26 per century)
#   n=20  beta=+0.01  fitted slope +0.0226  (+2.26 per century)
#   n=20  beta=+0.02  fitted slope +0.0326  (+3.26 per century)
#   n=20  beta=+0.03  fitted slope +0.0424  (+4.24 per century)
#   n=20  beta=+0.04  fitted slope +0.0526  (+5.26 per century)
#   n=30  stable      fitted slope -0.0105  (-1.05 per century)
#   n=30  beta=+0.01  fitted slope +0.0203  (+2.03 per century)
#   n=30  beta=+0.02  fitted slope +0.0305  (+3.05 per century)
#   n=30  beta=+0.03  fitted slope +0.0403  (+4.03 per century)
#   n=30  beta=+0.04  fitted slope +0.0503  (+5.03 per century)

# Displayed integer y values of the frozen STABLE example, keyed by n.
EXAMPLE_STABLE_Y = {
    3: [
        38, 39, 36
    ],
    4: [
        45, 47, 45, 43
    ],
    5: [
        72, 66, 66, 69, 68
    ],
    15: [
        61, 58, 66, 67, 64, 65, 62, 56, 63, 63, 63, 67, 61, 55, 64
    ],
    20: [
        56, 58, 61, 53, 54, 55, 55, 54, 55, 58, 55, 56, 59, 57, 54, 53, 53, 58, 51, 59
    ],
    30: [
        56, 53, 55, 59, 59, 59, 51, 56, 59, 57, 58, 56, 56, 49, 58, 60, 52, 54, 54,
        57, 54, 54, 58, 56, 61, 54, 51, 56, 62, 50
    ],
}

# Displayed integer y values of the frozen GROWING example, keyed by
# (n, beta_pos) with beta_pos the per-year slope.
EXAMPLE_GROWING_Y = {
    (3, 0.01): [
        56, 57, 59
    ],
    (3, 0.02): [
        79, 80, 83
    ],
    (3, 0.03): [
        79, 79, 84
    ],
    (3, 0.04): [
        71, 74, 77
    ],
    (4, 0.01): [
        43, 44, 49, 45
    ],
    (4, 0.02): [
        67, 66, 71, 70
    ],
    (4, 0.03): [
        40, 38, 41, 45
    ],
    (4, 0.04): [
        63, 62, 68, 68
    ],
    (5, 0.01): [
        62, 66, 65, 62, 68
    ],
    (5, 0.02): [
        50, 53, 52, 53, 55
    ],
    (5, 0.03): [
        46, 53, 51, 52, 53
    ],
    (5, 0.04): [
        40, 44, 39, 43, 48
    ],
    (15, 0.01): [
        66, 65, 66, 69, 73, 69, 69, 71, 69, 70, 73, 66, 70, 69, 68
    ],
    (15, 0.02): [
        47, 47, 50, 47, 53, 46, 46, 47, 45, 53, 49, 49, 53, 52, 49
    ],
    (15, 0.03): [
        45, 47, 45, 44, 45, 50, 47, 50, 44, 50, 48, 46, 53, 48, 49
    ],
    (15, 0.04): [
        65, 64, 66, 68, 66, 70, 64, 65, 67, 66, 74, 74, 69, 70, 67
    ],
    (20, 0.01): [
        77, 74, 77, 80, 70, 75, 73, 74, 83, 74, 75, 80, 76, 74, 79, 72, 79, 77, 79, 78
    ],
    (20, 0.02): [
        42, 44, 50, 42, 47, 47, 50, 48, 49, 46, 48, 47, 48, 53, 48, 51, 49, 46, 47, 46
    ],
    (20, 0.03): [
        45, 47, 46, 48, 45, 47, 48, 46, 48, 47, 52, 48, 52, 49, 52, 47, 51, 52, 46, 49
    ],
    (20, 0.04): [
        72, 75, 77, 79, 82, 75, 81, 78, 77, 77, 79, 82, 79, 78, 84, 81, 81, 78, 80, 81
    ],
    (30, 0.01): [
        79, 73, 80, 77, 76, 76, 78, 78, 80, 76, 78, 76, 80, 73, 78, 77, 78, 75, 79,
        76, 81, 81, 77, 80, 77, 78, 79, 80, 81, 76
    ],
    (30, 0.02): [
        46, 46, 44, 47, 48, 48, 47, 46, 47, 50, 43, 47, 47, 46, 42, 46, 48, 45, 44,
        47, 47, 51, 44, 44, 51, 45, 54, 52, 51, 47
    ],
    (30, 0.03): [
        50, 51, 51, 47, 56, 50, 54, 52, 55, 52, 48, 49, 53, 53, 52, 56, 53, 52, 53,
        52, 53, 50, 55, 57, 56, 54, 57, 53, 54, 53
    ],
    (30, 0.04): [
        41, 40, 37, 34, 37, 35, 39, 38, 39, 39, 40, 39, 42, 43, 40, 38, 40, 36, 37,
        44, 43, 38, 43, 45, 40, 43, 43, 39, 42, 43
    ],
}

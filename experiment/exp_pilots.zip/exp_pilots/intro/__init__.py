from otree.api import *
import json
from .quiz_items import QUIZ_ITEMS
from .example_stimuli import EXAMPLE_STABLE_Y, EXAMPLE_GROWING_Y
from main import stimulus

# oTree's own dev/production binary (settings.DEBUG = not OTREE_PRODUCTION).
# It is the ONLY gate on the testing skip controls: no custom flag, nothing to
# remember to switch off, and they vanish automatically in production.
from settings import DEBUG as _DEBUG

doc = """
Instructions (one page per instruction-block in instructions_text.html) and
the comprehension quiz from pilot_design.tex. Participants cannot proceed
until every quiz answer is correct (unless verify_quiz is False).
"""


class C(BaseConstants):
    NAME_IN_URL = 'Introduction'
    PLAYERS_PER_GROUP = None
    NUM_ROUNDS = 1


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


# Dynamically generate Player fields from QUIZ_ITEMS
def make_quiz_fields():
    fields = {
        'num_failed_attempts': models.IntegerField(initial=0),
    }
    for item in QUIZ_ITEMS:
        fields[item['field']] = models.StringField(
            label=item['prompt'],
            widget=widgets.RadioSelect,
            choices=item['choices'],
        )
    return fields


class Player(BasePlayer):
    locals().update(make_quiz_fields())


# FUNCTIONS

def example_figures(player: Player):
    """The FROZEN worked-example pair for this participant's FIRST-BLOCK n.

    Deterministic and identical for every participant with the same (n, beta):
    the coordinates come straight out of example_stimuli.py, which was built
    offline. NOTHING is drawn here — no RNG is touched on this code path — so
    the illustration cannot vary between participants or between page loads.

    Unlike the task stimulus these DO show the fitted line (show_fit=True): the
    line is the entire point of the illustration.
    """
    cfg = player.session.config
    n = player.participant.pilot_block_ns[0]      # the n of their FIRST block
    beta_pos = player.participant.pilot_beta_pos
    xs = stimulus.make_x_grid(n, cfg)
    stable_ys = EXAMPLE_STABLE_Y[n]
    growing_ys = EXAMPLE_GROWING_Y[(n, beta_pos)]
    return {
        'example_n': n,
        'example_stable_svg': stimulus.scatter_svg(
            xs, stable_ys, cfg, show_fit=True, compact=True),
        'example_growing_svg': stimulus.scatter_svg(
            xs, growing_ys, cfg, show_fit=True, compact=True),
    }


def instruction_vars(player: Player):
    """Everything instructions_text.html references, all from the session config
    or the participant's assigned treatment — no hard-coded design quantities."""
    cfg = player.session.config
    num_blocks = len(cfg['n_novice'])
    prior_stable, prior_growing = cfg['prior']
    num_rounds = num_blocks * cfg['rounds_per_block']
    # The noise table: displayed deviation from the island average, in years
    # out of 100 (computed from sigma_eps, largest-remainder rounded to sum
    # exactly 100; symmetric, so one number serves "below" and "above").
    nt = stimulus.noise_years_table(cfg['sigma_eps'])
    start_pos_pct, start_stable_pct = stimulus.slider_start_pcts(cfg)
    return {
        # growth is ALWAYS stated in whole coconuts per 100 years, never as a
        # per-year decimal slope
        'beta_per_century': f"{player.participant.pilot_beta_pos * 100:g}",
        'num_rounds': num_rounds,
        'num_blocks': num_blocks,
        'rounds_per_block': cfg['rounds_per_block'],
        'paid_rounds_total': min(cfg['paid_rounds_total'], num_rounds),
        # the prior, stated as island counts (800 stable / 200 growing of 1000)
        'islands_total': cfg['islands_total'],
        'islands_stable': round(cfg['islands_total'] * prior_stable),
        'islands_growing': round(cfg['islands_total'] * prior_growing),
        # the practice bet widget opens at the SAME split as the real task
        # control (cfg['slider_start']; None = the prior). Single source of
        # truth in stimulus.slider_start_pcts, so demo and task can never drift.
        'start_stable_pct': start_stable_pct,
        'start_pos_pct': start_pos_pct,
        'noise_3plus': nt[0], 'noise_2': nt[1], 'noise_1': nt[2], 'noise_0': nt[3],
        'base_payment': cu(cfg['base_payment']),
        'scoring_prize': cu(cfg['scoring_prize']),
        'quiz_bonus': cu(cfg['quiz_bonus']),
        'has_quiz_bonus': cfg['quiz_bonus'] > 0,
        **example_figures(player),
    }


# PAGES

class instructing(Page):
    template_name = 'intro/templates/instructing.html'

    @staticmethod
    def vars_for_template(player: Player):
        # This page is pure display: no form_model, no form_fields, no
        # before_next_page. It initialises NOTHING, so the dev skip below simply
        # submits it early and no downstream state is lost. (Everything the rest
        # of the app depends on — consent, failed_attempts, task_records,
        # finish_reason, the Prolific label — is set in before/Welcome's
        # before_next_page, and treatment assignment happens in
        # before/creating_session. The skip touches none of them.)
        return dict(instruction_vars(player), dev_skip=_DEBUG)


class quiz(Page):
    template_name = 'intro/templates/quiz.html'
    form_model = 'player'
    quiz_field_names = [item['field'] for item in QUIZ_ITEMS]
    quiz_solutions = [item['answer'] for item in QUIZ_ITEMS]

    @staticmethod
    def get_form_fields(player: Player):
        return quiz.quiz_field_names

    @staticmethod
    def error_message(player: Player, values):
        # NOTE ON THE DEV SKIP: it submits the CORRECT answers through this same
        # validation rather than bypassing it, so a skipped quiz records ZERO
        # failed attempts (and therefore counts as bonus-eligible, exactly as a
        # first-time-correct human would). That is the deliberate choice: the
        # counter is never corrupted by a special case, because there is no
        # special case — the skip is indistinguishable from answering correctly.
        # It is also unreachable in production, so it cannot affect real data.

        # Skip validation entirely when quiz verification is disabled (testing)
        if not player.session.config.get('verify_quiz', True):
            return
        solutions = dict(zip(quiz.quiz_field_names, quiz.quiz_solutions))
        wrong = [key for key in solutions if values.get(key, '') != solutions[key]]
        if wrong:
            player.num_failed_attempts += 1
            player.participant.failed_attempts += 1
            return ("One or more quiz answers are wrong. You can re-read the "
                    "instructions below and try again.")

    @staticmethod
    def vars_for_template(player: Player):
        # dev_skip_answers is the ONLY path by which the correct answers reach
        # the browser, and it is empty unless DEBUG. In production the page has
        # no way to know them, so the skip cannot be re-enabled client-side.
        return dict(
            instruction_vars(player),
            dev_skip=_DEBUG,
            dev_skip_answers=(
                json.dumps(dict(zip(quiz.quiz_field_names, quiz.quiz_solutions)))
                if _DEBUG else ''),
        )


page_sequence = [instructing, quiz]

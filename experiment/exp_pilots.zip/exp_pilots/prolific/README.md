# Prolific wiring — calibration pilot

The full background guide is `../../ExpExperts/prolific/Prolific_running.md`
(Part 1: completion flow — implemented here; Part 2: tab-switch monitor — NOT
implemented, add it before launch if desired).

What is already wired in this app:

- **Prolific ID capture** — the consent page (`before/`) stores the
  participant label (set it via the study URL, below) and mirrors it into
  `player.prolific_id`; a JS fallback reads a `?PROLIFIC_PID=` query param.
- **Completion codes** — per-session-config keys in `settings.py`:
  `cc_code` (normal completion) and `noconsent_code` (declined consent).
  Replace the `REPLACE_*` placeholders with the codes from the Prolific
  study page before launch.
- **Finish screens** — `outro/Results` (normal, shows the payment breakdown,
  "Back to Prolific" button) and `before/NoConsentWithdrawal` (consent
  declined: a withdrawal page right after the consent page with a "Withdraw
  and return to Prolific" button that redirects with `noconsent_code`).
  `outro/NoConsent` remains as a fallback ending for a non-consenter who
  advances past the withdrawal page without clicking the button.

Prolific study settings:

1. Study URL: `https://experiment.juliantait.eu/join/<session_code>?participant_label={{%PROLIFIC_PID%}}`
   (create the 160-slot `pilot` session in the oTree admin first and use its
   session-wide link).
2. Completion codes: create one "Completed" code and one "Returned/No consent"
   code in Prolific; paste them into `cc_code` / `noconsent_code`.
3. Base reward: the `base_payment` amount (£1). Bonuses: pay via Prolific's
   bulk bonus upload using the data export (`player.bonus_total` in the outro
   app, matched on the participant label = Prolific ID).

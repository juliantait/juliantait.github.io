"""
Scoring for the allocation task — SAME rule as the main study
(ExpExperts/main/scoring.py).

The allocation a = (a_flat, a_pos) splits a unit stake over the two candidate slopes.
We store only the mass on the positive slope (`a_pos`); the mass on the flat
slope is 1 - a_pos.

HOSSAIN & OKUI (2013) BINARISED QUADRATIC SCORING RULE. For a binary state,
reporting allocation a when the realised state has mass `m` on it wins a fixed
prize with probability

    win_prob = 1 - (1 - m)^2 ,

binarised by comparing 1 - (1 - m)^2 to a uniform draw. Expected payoff is
maximised by reporting m = posterior probability of the realised state, i.e.
truthful reporting of the posterior is optimal regardless of risk attitude.

This is the Hossain-Okui binarised quadratic rule, NOT the Vespa & Wilson (2017)
paired-uniform mechanism (a different lottery-threshold, plain-language scheme
for eliciting a single probability); Vespa-Wilson is only a related alternative,
never the rule used here.
"""


def mass_on_state(a_pos, state_is_pos):
    """Allocation mass placed on the realised state."""
    return a_pos if state_is_pos else (1.0 - a_pos)


def binarised_win_prob(a_pos, state_is_pos):
    """Probability of winning the prize under the Hossain-Okui (2013) binarised
    quadratic scoring rule."""
    m = mass_on_state(a_pos, state_is_pos)
    return 1.0 - (1.0 - m) ** 2


def score_allocation(a_pos, state_is_pos, prize, uniform_draw):
    """Binarised payoff: win `prize` iff a uniform draw falls under win_prob.

    Returns (payoff, win_prob, won).
    """
    win_prob = binarised_win_prob(a_pos, state_is_pos)
    won = uniform_draw <= win_prob
    return (prize if won else 0.0), win_prob, won

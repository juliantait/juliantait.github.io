"""
Stimulus generation and rendering for the calibration pilot (coconut islands).

Data-generating process (per round, parameters from the session config):

    y_continuous = baseline + beta * (t - t_mid) + eps ,  eps ~ N(0, sigma_eps^2)
    displayed    = round(y_continuous)                    (nearest integer)

* The true beta is drawn FRESH EVERY ROUND from `prior` over the participant's
  BETA ARM pair (nothing pre-generated, nothing reused). Slopes are per-year;
  participant-facing text speaks in whole coconuts per 100 years.
* `baseline` (the island's average production at mid-window) is an integer
  drawn uniform on [baseline_min, baseline_max] fresh every round.
* The t grid is n evenly spaced observation years over the shared window
  [x_min, x_max] -- the same window at every n, so the standard error of the
  OLS slope scales purely with n. The story explains the gaps between
  observation years as missing records.

ROUNDING HAPPENS AT GENERATION, AND EVERYTHING DERIVED IS COMPUTED FROM THE
ROUNDED VALUES. The integers are the stimulus participants actually see; every
derived quantity (beta_hat, se, llr, posterior, the plot) must be computed
from them, NEVER from the raw continuous draws. The continuous draws are
stored only as bookkeeping, to verify the randomness is genuine (see
reports/integer_rounding_effects.md: rounding is harmless for inference, but
mixing the two worlds in derived quantities would describe a stimulus the
participants never saw).

Nothing here is hard-coded: every quantity is passed in from the session
config. No oTree imports, so verify_randomisation.py can reuse it.
"""

import json
import random
import math


# ---------------------------------------------------------------------------
# Data generation
# ---------------------------------------------------------------------------

def draw_true_beta(beta_pair, prior, rng=random):
    """Draw the round's true slope from the prior over the participant's pair."""
    return rng.choices(list(beta_pair), weights=list(prior), k=1)[0]


def slider_start_pcts(cfg):
    """(points on Growing, points on Stable) for the bet control's opening split.

    cfg['slider_start'] is the starting points-on-Growing value (0..100). When it
    is None (the default) the control opens AT THE PRIOR — the growing share of
    the island population, round(prior_growing * 100) — so an untouched
    submission records the prior rather than a flat 50/50. A single source of
    truth shared by the real task screen and the instructions practice demo, so
    the two can never disagree.
    """
    start = cfg.get('slider_start')
    if start is None:
        _, prior_growing = cfg['prior']
        start = round(prior_growing * 100)
    start = max(0, min(100, int(start)))
    return start, 100 - start


def make_x_grid(n, cfg):
    """Observation years for a chart with n dots over the shared window."""
    x_min, x_max = cfg['x_min'], cfg['x_max']
    mode = cfg.get('x_mode', 'fixed_even')
    if mode == 'random':
        # Placeholder alternative design: i.i.d. uniform draws over the window.
        return [random.uniform(x_min, x_max) for _ in range(n)]
    # Default 'fixed_even': evenly spaced years over the window.
    if n == 1:
        return [(x_min + x_max) / 2.0]
    step = (x_max - x_min) / (n - 1)
    return [x_min + i * step for i in range(n)]


def sample_points(n, true_beta, cfg, rng=random):
    """Return (xs, ys, ys_raw, baseline) for one stimulus.

    ys are the DISPLAYED integer productions (round of the continuous draw);
    ys_raw are the raw continuous draws underneath them. The integers are the
    stimulus: compute every derived quantity from `ys`, never from `ys_raw`.
    """
    sigma = cfg['sigma_eps']
    xs = make_x_grid(n, cfg)
    t_mid = (cfg['x_min'] + cfg['x_max']) / 2.0
    baseline = rng.randint(cfg['baseline_min'], cfg['baseline_max'])
    ys_raw = [baseline + true_beta * (x - t_mid) + rng.gauss(0.0, sigma)
              for x in xs]
    ys = [int(round(y)) for y in ys_raw]
    return xs, ys, ys_raw, baseline


# ---------------------------------------------------------------------------
# OLS slope and standard error (stored per round for convenience; the stored
# point data are the authoritative record and everything is reconstructable).
# Callers must pass the DISPLAYED integer ys.
# ---------------------------------------------------------------------------

def ols_slope_se(xs, ys):
    """Return (beta_hat, se) from a simple OLS regression of y on x.

    se is the usual estimated standard error of the slope; requires n >= 3.
    """
    n = len(xs)
    xbar = sum(xs) / n
    ybar = sum(ys) / n
    ss_xx = sum((x - xbar) ** 2 for x in xs)
    ss_xy = sum((x - xbar) * (y - ybar) for x, y in zip(xs, ys))
    if ss_xx == 0:
        return 0.0, float('inf')
    beta_hat = ss_xy / ss_xx
    intercept = ybar - beta_hat * xbar
    resid = [y - (intercept + beta_hat * x) for x, y in zip(xs, ys)]
    if n > 2:
        s2 = sum(r * r for r in resid) / (n - 2)
        se = math.sqrt(s2 / ss_xx)
    else:
        se = float('inf')
    return beta_hat, se


def log_likelihood_ratio(xs, ys, beta_pair, sigma):
    """log [ L(beta_growing) / L(beta_stable) ] for the realised draw.

    The island's baseline is a nuisance intercept: it is marginalised out
    under a flat prior (equivalently profiled -- the Gaussian integral
    constant is identical under both slopes and cancels), so the LLR is
    computed on mean-centred data:

        LLR = [ S(beta_stable) - S(beta_growing) ] / (2 sigma^2),
        S(b) = sum_i ( (y_i - ybar) - b (x_i - xbar) )^2 .

    With beta_stable = 0 this reduces to the closed form in
    reports/integer_rounding_effects.md:  beta_+ * SS_xx * (beta_hat -
    beta_+/2) / sigma^2. Pass the DISPLAYED integer ys.
    """
    beta_stable, beta_growing = beta_pair
    n = len(xs)
    xbar = sum(xs) / n
    ybar = sum(ys) / n
    xc = [x - xbar for x in xs]
    yc = [y - ybar for y in ys]

    def rss(b):
        return sum((y - b * x) ** 2 for x, y in zip(xc, yc))

    return (rss(beta_stable) - rss(beta_growing)) / (2 * sigma ** 2)


def posterior_pos(xs, ys, beta_pair, prior, sigma):
    """Exact Bayesian posterior P(beta = beta_growing | data), baseline
    marginalised (see log_likelihood_ratio). Pass the DISPLAYED integer ys."""
    llr = log_likelihood_ratio(xs, ys, beta_pair, sigma)
    prior_stable, prior_growing = prior
    # posterior odds = likelihood ratio * prior odds
    log_odds = llr + math.log(prior_growing / prior_stable)
    if log_odds > 700:      # avoid overflow; posterior is 1 to machine precision
        return 1.0
    return 1.0 / (1.0 + math.exp(-log_odds))


# ---------------------------------------------------------------------------
# The instructions' noise table: how often the DISPLAYED production lands
# k coconuts from the island's average, in years out of 100.
# ---------------------------------------------------------------------------

def noise_years_table(sigma):
    """Integer 'years out of 100' for displayed deviations
    (3+ below, 2 below, 1 below, exactly equal, 1 above, 2 above, 3+ above).

    The displayed deviation is round(eps) with eps ~ N(0, sigma^2), so
    P(round(eps) = k) = Phi((k+.5)/sigma) - Phi((k-.5)/sigma). Percentages are
    rounded to integers by LARGEST REMAINDER so they sum to exactly 100
    (sorted() is stable, so the result is deterministic). For sigma = 2.5:
    [16, 11, 15, 16, 15, 11, 16].
    """
    def phi(z):
        return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))

    p0 = phi(0.5 / sigma) - phi(-0.5 / sigma)
    p1 = phi(1.5 / sigma) - phi(0.5 / sigma)
    p2 = phi(2.5 / sigma) - phi(1.5 / sigma)
    p3plus = 1.0 - phi(2.5 / sigma)
    raw = [100.0 * p for p in (p3plus, p2, p1, p0, p1, p2, p3plus)]
    out = [int(x) for x in raw]
    remainder_order = sorted(range(7), key=lambda i: raw[i] - out[i], reverse=True)
    for i in remainder_order[:100 - sum(out)]:
        out[i] += 1
    return out


# ---------------------------------------------------------------------------
# Rendering (inline SVG built as a plain string -- NO third-party imports)
# ---------------------------------------------------------------------------
#
# The stimulus is dots on axes, so it is drawn as vector SVG assembled here in
# pure Python. This is deliberate: no image library, nothing to install, no
# raster encoding on every page load, and the result stays sharp on high-DPI
# phone screens (it runs on Prolific).
#
# FIXED Y RANGE. The y axis is the same on EVERY chart and is never
# autoscaled. Autoscaling would rescale each chart to its own spread and so
# hide exactly the noise differences the design turns on. The displayed
# production is baseline + trend + noise with baseline in [40, 80], the trend
# at most 0.04 * 50 = 2 coconuts from the baseline at the window edges, and
# noise ~ N(0, 2.5^2), so a dot escapes the range only if |eps| exceeds about
# 4.5 sigma (p ~ 7e-6 per dot; well under one dot expected across the run).
# If one ever does occur it is still drawn, just outside the frame, never
# clipped away. The range is derived from the config so the margin survives a
# change to sigma_eps / the beta arms / the baseline range.

_Y_SIGMA_MARGIN = 4.5     # sigmas of headroom beyond the largest trend value


def y_range(cfg):
    """Fixed (never autoscaled) (y_lo, y_hi) of the y axis, shared by all
    charts, snapped outward to multiples of 5. Defaults: (25, 95)."""
    if cfg.get('y_lo') is not None and cfg.get('y_hi') is not None:
        return float(cfg['y_lo']), float(cfg['y_hi'])
    sigma = cfg['sigma_eps']
    max_beta = max(abs(b) for pair in cfg['beta_pairs'] for b in pair)
    half_window = (cfg['x_max'] - cfg['x_min']) / 2.0
    margin = max_beta * half_window + _Y_SIGMA_MARGIN * sigma
    y_lo = 5 * math.floor((cfg['baseline_min'] - margin) / 5)
    y_hi = 5 * math.ceil((cfg['baseline_max'] + margin) / 5)
    return float(y_lo), float(y_hi)


def _tick_step(span, max_ticks):
    """Smallest 'nice' step giving at most max_ticks intervals over span."""
    for step in (1, 2, 5, 10, 20, 25, 50, 100):
        if span / step <= max_ticks:
            return step
    return span


def _fmt(v):
    """Compact fixed-point coordinate (SVG user units); avoids 1e-17 noise."""
    return f'{v:.2f}'.rstrip('0').rstrip('.') or '0'


def scatter_svg(xs, ys, cfg, show_fit=False, compact=False):
    """Return the stimulus as an inline <svg> string (ys = displayed integers).

    show_fit=False (THE DEFAULT, and the only value the task ever uses) draws
    the dots and axes ONLY: no fitted line and no true-trend line, because
    judging the trend IS the task. The AllocationScreen must never pass True.

    show_fit=True is for the worked EXAMPLE figures in the instructions, which
    are a different thing entirely and are allowed to show the fitted line --
    that line is the whole point of the illustration.

    compact=True trims the chrome (no title, fewer tick labels) so two
    examples sit side by side without becoming unreadable on a phone.
    """
    # --- geometry (viewBox units; the element scales to its container) -------
    W, H = 480.0, 340.0
    ml, mr, mt, mb = 52.0, 18.0, 34.0, 44.0
    pw, ph = W - ml - mr, H - mt - mb

    x_min, x_max = float(cfg['x_min']), float(cfg['x_max'])
    pad = 0.05 * (x_max - x_min)
    xlo, xhi = x_min - pad, x_max + pad
    y_lo, y_hi = y_range(cfg)

    def px(x):
        return ml + (x - xlo) / (xhi - xlo) * pw

    def py(y):
        return mt + (y_hi - y) / (y_hi - y_lo) * ph      # y up

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {_fmt(W)} {_fmt(H)}" '
        f'role="img" aria-label="Chart of one island\'s coconut production in '
        f'{len(xs)} recorded years" '
        f'style="width:100%;height:auto;display:block;">',
        '<rect x="0" y="0" width="100%" height="100%" fill="#ffffff"/>',
    ]
    if not compact:
        parts.append(
            f'<text x="{_fmt(W / 2)}" y="21" text-anchor="middle" font-family="system-ui,'
            f'sans-serif" font-size="16" font-weight="600" fill="#333">'
            f'This island&#8217;s coconut production</text>')

    # --- gridlines + tick labels --------------------------------------------
    x_step = _tick_step(x_max - x_min, 6)
    xticks = [x_min + i * x_step for i in range(int((x_max - x_min) / x_step) + 1)]
    y_step = _tick_step(y_hi - y_lo, 8)
    first_yt = y_step * math.ceil(y_lo / y_step)
    yticks = []
    yt = first_yt
    while yt <= y_hi:
        yticks.append(yt)
        yt += y_step

    for xt in xticks:
        X = px(xt)
        parts.append(f'<line x1="{_fmt(X)}" y1="{_fmt(mt)}" x2="{_fmt(X)}" '
                     f'y2="{_fmt(mt + ph)}" stroke="#eceff3" stroke-width="1"/>')
        parts.append(f'<text x="{_fmt(X)}" y="{_fmt(mt + ph + 19)}" text-anchor="middle" '
                     f'font-family="system-ui,sans-serif" font-size="14" fill="#555">'
                     f'{xt:g}</text>')
    for yt in yticks:
        Y = py(yt)
        parts.append(f'<line x1="{_fmt(ml)}" y1="{_fmt(Y)}" x2="{_fmt(ml + pw)}" '
                     f'y2="{_fmt(Y)}" stroke="#eceff3" stroke-width="1"/>')
        parts.append(f'<text x="{_fmt(ml - 9)}" y="{_fmt(Y + 5)}" text-anchor="end" '
                     f'font-family="system-ui,sans-serif" font-size="14" fill="#555">'
                     f'{yt:g}</text>')

    # --- frame ----------------------------------------------------------------
    parts.append(f'<rect x="{_fmt(ml)}" y="{_fmt(mt)}" width="{_fmt(pw)}" '
                 f'height="{_fmt(ph)}" fill="none" stroke="#ccd5e0" stroke-width="1"/>')

    # --- axis titles ---------------------------------------------------------
    parts.append(f'<text x="{_fmt(ml + pw / 2)}" y="{_fmt(H - 6)}" text-anchor="middle" '
                 f'font-family="system-ui,sans-serif" font-size="15" fill="#333">Year</text>')
    parts.append(f'<text x="14" y="{_fmt(mt + ph / 2)}" text-anchor="middle" '
                 f'font-family="system-ui,sans-serif" font-size="15" fill="#333" '
                 f'transform="rotate(-90 14 {_fmt(mt + ph / 2)})">Coconuts</text>')

    # --- the FITTED line: instruction examples ONLY, never the task ----------
    # Drawn under the dots so it never hides a point. Fitted to the DISPLAYED
    # integers -- the same dots the figure shows.
    if show_fit and len(xs) >= 2:
        bhat, _ = ols_slope_se(xs, ys)
        xbar = sum(xs) / len(xs)
        ybar = sum(ys) / len(ys)
        intercept = ybar - bhat * xbar
        y0, y1 = intercept + bhat * xlo, intercept + bhat * xhi
        parts.append(f'<line x1="{_fmt(px(xlo))}" y1="{_fmt(py(y0))}" '
                     f'x2="{_fmt(px(xhi))}" y2="{_fmt(py(y1))}" '
                     f'stroke="#d1495b" stroke-width="2.5" stroke-linecap="round"/>')

    # --- the dots (exact stored displayed integers) ---------------------------
    for x, y in zip(xs, ys):
        parts.append(f'<circle cx="{_fmt(px(x))}" cy="{_fmt(py(y))}" r="5" '
                     f'fill="#2c6fbb" fill-opacity="0.75"/>')

    parts.append('</svg>')
    return ''.join(parts)


# ---------------------------------------------------------------------------
# (De)serialisation for storing point clouds on model fields. json.dumps keeps
# full double precision (repr round-trip) for the raw draws; the displayed
# values are exact integers. Storing BOTH is the recording requirement: the
# integers are the stimulus, the raws exist to verify the randomness is
# genuine (rounding can make realised draws look less random than they are).
# ---------------------------------------------------------------------------

def dumps_xy(xs, ys, ys_raw):
    return json.dumps({'x': xs, 'y': ys, 'y_raw': ys_raw})


def loads_xy(blob):
    """Return (xs, ys) -- the DISPLAYED integers, i.e. what rendering and
    every derived quantity must use."""
    if not blob:
        return [], []
    d = json.loads(blob)
    return d.get('x', []), d.get('y', [])

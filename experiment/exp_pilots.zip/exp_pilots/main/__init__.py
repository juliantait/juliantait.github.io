from otree.api import *

from . import stimulus
from . import scoring  # noqa: F401  (imported for outro/payment; same rule as ExpExperts)

# oTree fixes C.NUM_ROUNDS at import time, so the round count is resolved once
# here from the session defaults (single source of truth: settings.py). Configs
# may run FEWER rounds (pages beyond their total are skipped) but never more.
from settings import SESSION_CONFIG_DEFAULTS as _DEFAULTS

doc = """
Calibration pilot (coconut islands): single-player judgement task. Each round
the participant sees one island's yearly coconut production (displayed as
integers; y = baseline + beta*(t - t_mid) + noise, rounded) and, on ONE
screen, bets 100 points across "stable" (beta = 0) and "growing" (beta > 0)
under the same allocation interface and scoring rule as ExpExperts. The bet is
the one and only elicited object (no separate guess, no confidence slider).
No groups, no discussion, no vote, no WTP. See ../LaTeX/pilot_design.tex.
"""


def _num_blocks(cfg):
    if len(cfg['n_novice']) != len(cfg['n_expert']):
        raise ValueError("n_novice and n_expert must have the same length")
    return len(cfg['n_novice'])


def _total_rounds(cfg):
    return _num_blocks(cfg) * cfg['rounds_per_block']


class C(BaseConstants):
    NAME_IN_URL = 'main'
    PLAYERS_PER_GROUP = None      # single-player: no groups anywhere
    NUM_ROUNDS = _total_rounds(_DEFAULTS)


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    # ---- treatment copies (participant-level facts repeated per round so the
    # ---- flat per-round data export is self-contained) ----------------------
    assigned_role = models.StringField()          # 'NOVICE' | 'EXPERT' ('role' is reserved)
    beta_pos = models.FloatField()                # growing candidate slope (per year)
    block_number = models.IntegerField()          # 1-based block position
    round_in_block = models.IntegerField()        # 1-based round within the block
    n_points = models.IntegerField()

    # ---- realised stimulus ----------------------------------------------------
    true_beta = models.FloatField()               # drawn fresh from the prior
    state_is_pos = models.BooleanField()          # True iff true_beta == beta_pos (growing)
    baseline = models.IntegerField()              # island average production at mid-window
    # JSON {x:[...], y:[...], y_raw:[...]}: y = displayed integers (THE
    # stimulus), y_raw = the continuous draws underneath (bookkeeping only, to
    # verify the randomness is genuine).
    xy_data = models.LongStringField(blank=True)

    # ---- derived stats (convenience only; reconstructable from xy_data) ------
    # ALL computed from the DISPLAYED integers, never from y_raw: the analysis
    # must describe the stimulus participants actually saw.
    beta_hat = models.FloatField(blank=True)      # realised OLS slope (from displayed y)
    se = models.FloatField(blank=True)            # OLS slope SE (None if undefined)
    llr = models.FloatField(blank=True)           # log-likelihood ratio growing vs stable
    posterior = models.FloatField(blank=True)     # exact Bayesian posterior on growing

    # ---- elicitation (the 100-point bet is the ONLY elicited object) ---------
    allocation_pos_pct = models.IntegerField(min=0, max=100)  # points on growing, of 100
    rt_ms = models.FloatField(blank=True)               # page load -> submit, ms


# ===========================================================================
# SESSION / ROUND SETUP
# ===========================================================================

def creating_session(subsession: Subsession):
    cfg = subsession.session.config
    if subsession.round_number == 1 and _total_rounds(cfg) > C.NUM_ROUNDS:
        raise ValueError(
            f"This session config implies {_total_rounds(cfg)} rounds but the app was "
            f"imported with NUM_ROUNDS={C.NUM_ROUNDS}. Raise rounds_per_block / the "
            "n-lists in settings.SESSION_CONFIG_DEFAULTS (the import-time source)."
        )
    if subsession.round_number > _total_rounds(cfg):
        return  # config runs fewer rounds than NUM_ROUNDS; pages there are skipped

    rpb = cfg['rounds_per_block']
    block_index = (subsession.round_number - 1) // rpb          # 0-based
    round_in_block = (subsession.round_number - 1) % rpb + 1    # 1-based

    for player in subsession.get_players():
        part = player.participant
        player.assigned_role = part.pilot_role
        player.beta_pos = part.pilot_beta_pos
        player.block_number = block_index + 1
        player.round_in_block = round_in_block
        player.n_points = part.pilot_block_ns[block_index]

        # Fresh independent draw EVERY round: new true state, new baseline,
        # new noise.
        true_beta = stimulus.draw_true_beta(part.pilot_beta_pair, cfg['prior'])
        player.true_beta = true_beta
        player.state_is_pos = (true_beta == part.pilot_beta_pos)

        xs, ys, ys_raw, baseline = stimulus.sample_points(
            player.n_points, true_beta, cfg)
        player.baseline = baseline
        player.xy_data = stimulus.dumps_xy(xs, ys, ys_raw)

        # Derived quantities come from the DISPLAYED integers (ys), never from
        # ys_raw: rounding happens at generation and the integers ARE the
        # stimulus. Deriving anything from the continuous draws would describe
        # data the participant never saw.
        bh, se = stimulus.ols_slope_se(xs, ys)
        player.beta_hat = bh
        player.se = se if se != float('inf') else None
        player.llr = stimulus.log_likelihood_ratio(
            xs, ys, part.pilot_beta_pair, cfg['sigma_eps'])
        player.posterior = stimulus.posterior_pos(
            xs, ys, part.pilot_beta_pair, cfg['prior'], cfg['sigma_eps'])


# ===========================================================================
# HELPERS
# ===========================================================================

def _scatter_svg(player: Player):
    """Inline SVG for the round's stimulus (displayed integer dots only; no
    fitted/true line). The y axis is the constant-height per-round window centred
    on this island's mid-window average (player.baseline) — see stimulus.y_window."""
    xs, ys = stimulus.loads_xy(player.xy_data)
    return stimulus.scatter_svg(xs, ys, player.session.config,
                                y_center=player.baseline, plot_id='task')


def _paid_rounds_total(cfg):
    # Paid rounds are drawn from ALL rounds (not per block); a config that
    # runs fewer rounds than that (never in practice) caps at the total.
    return min(cfg['paid_rounds_total'], _total_rounds(cfg))


# ===========================================================================
# PAGES
# ===========================================================================

class BlockStart(Page):
    """Announce block progress and the round count for the coming block.

    Says the number of surviving records changes (the story's framing of n
    changing between blocks) but deliberately does NOT state the count itself:
    participants are never told n; they simply see the charts."""
    template_name = 'main/block_start.html'

    @staticmethod
    def is_displayed(player: Player):
        return (player.round_number <= _total_rounds(player.session.config)
                and player.round_in_block == 1)

    @staticmethod
    def vars_for_template(player: Player):
        cfg = player.session.config
        return {
            'block_number': player.block_number,
            'prev_block': player.block_number - 1,   # the block just finished
            'num_blocks': _num_blocks(cfg),
            'rounds_per_block': cfg['rounds_per_block'],
            'first_block': player.block_number == 1,
        }


class AllocationScreen(Page):
    """ONE screen: the island's chart + the 100-point stable/growing bet.
    The bet is the one and only elicited, incentivised object."""
    template_name = 'main/allocation_screen.html'
    form_model = 'player'
    form_fields = ['allocation_pos_pct', 'rt_ms']

    @staticmethod
    def is_displayed(player: Player):
        return player.round_number <= _total_rounds(player.session.config)

    @staticmethod
    def vars_for_template(player: Player):
        cfg = player.session.config
        start_pos_pct, start_stable_pct = stimulus.slider_start_pcts(cfg)
        return {
            'scatter_svg': _scatter_svg(player),
            # The bet control's opening split, from the session config
            # (cfg['slider_start'], points on Growing); None opens it at the
            # prior — see stimulus.slider_start_pcts. NOT a fixed 50/50: an
            # untouched submission records this split, so it sits on the prior.
            'start_pos_pct': start_pos_pct,
            'start_stable_pct': start_stable_pct,
            # ONE participant-facing counter: block + round within that block.
            # (No competing "round N of 24"; the bar below carries overall
            # progress silently, without a second number to reconcile.)
            'round_in_block': player.round_in_block,
            'rounds_per_block': cfg['rounds_per_block'],
            'block_number': player.block_number,
            'num_blocks': _num_blocks(cfg),
            'progress_pct': round(100.0 * player.round_number / _total_rounds(cfg)),
            # n_points is intentionally NOT passed to the task screen: the
            # per-chart record count is never shown to the participant.
            'min_view_seconds': cfg['min_view_seconds'],
            'scoring_prize': cu(cfg['scoring_prize']),
            'paid_rounds_total': _paid_rounds_total(cfg),
        }

    @staticmethod
    def before_next_page(player: Player, timeout_happened):
        # Per-round record for the end-of-session payment draw (paid rounds
        # drawn from ALL rounds) and as a convenient flat export.
        record = dict(
            round=player.round_number,
            block_number=player.block_number,
            round_in_block=player.round_in_block,
            n_points=player.n_points,
            true_beta=player.true_beta,
            state_is_pos=player.state_is_pos,
            baseline=player.baseline,
            allocation_pos=player.allocation_pos_pct / 100.0,
            rt_ms=player.rt_ms,
        )
        recs = list(player.participant.task_records or [])
        recs.append(record)
        player.participant.task_records = recs


page_sequence = [BlockStart, AllocationScreen]

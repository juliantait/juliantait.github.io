import json

from otree.api import Bot, Submission, expect

from . import BlockStart, AllocationScreen, _total_rounds, stimulus


class PlayerBot(Bot):
    def play_round(self):
        if not self.participant.consented:
            return  # routed straight to outro from `before`

        cfg = self.session.config
        if self.round_number > _total_rounds(cfg):
            return

        player = self.player
        part = self.participant

        # Stimulus sanity: n comes from this participant's block order, the
        # stored draw has exactly n points, and the state is one of the pair.
        expect(player.n_points, part.pilot_block_ns[player.block_number - 1])
        xy = json.loads(player.xy_data)
        expect(len(xy['x']), player.n_points)
        expect(len(xy['y']), player.n_points)
        expect(len(xy['y_raw']), player.n_points)
        expect(player.true_beta in part.pilot_beta_pair, True)
        expect(player.state_is_pos, player.true_beta == part.pilot_beta_pos)

        # The displayed values are integers, exactly the rounded raw draws,
        # and the baseline is in the configured range.
        expect(all(isinstance(y, int) for y in xy['y']), True)
        expect(all(y == int(round(yr)) for y, yr in zip(xy['y'], xy['y_raw'])),
               True)
        expect(cfg['baseline_min'] <= player.baseline <= cfg['baseline_max'],
               True)

        # Derived quantities are computed from the DISPLAYED integers, never
        # from the raw continuous draws (the recorded-data invariant).
        bh, se = stimulus.ols_slope_se(xy['x'], xy['y'])
        expect(abs(player.beta_hat - bh) < 1e-12, True)
        expect(abs(player.llr - stimulus.log_likelihood_ratio(
            xy['x'], xy['y'], part.pilot_beta_pair, cfg['sigma_eps'])) < 1e-12,
            True)
        expect(abs(player.posterior - stimulus.posterior_pos(
            xy['x'], xy['y'], part.pilot_beta_pair, cfg['prior'],
            cfg['sigma_eps'])) < 1e-12, True)

        if player.round_in_block == 1:
            yield BlockStart

        allocation = (player.round_number * 7) % 101
        # Exercise the popover-open flag: post 1 on round 1 (so a real open is
        # recorded and OR-accumulated to participant.info_opened) and 0 on every
        # other round (the untouched default). outro/tests.py asserts the
        # accumulated participant value is 1.
        popover_opened = 1 if player.round_number == 1 else 0
        yield Submission(
            AllocationScreen,
            dict(allocation_pos_pct=allocation, rt_ms=1234.5,
                 popover_opened=popover_opened),
            check_html=False)
        # NOTE: participant vars read here would be stale (bot object caching);
        # the per-round task_records are verified in outro/tests.py instead.

#!/usr/bin/env python3
"""
Randomisation verification for the calibration pilot (run: python3 verify_randomisation.py).

Simulates many participants through the ACTUAL assignment and stimulus code
(before/treatment_assignment.py, main/stimulus.py — imported directly, no oTree
needed) and checks:

  1. CELL BALANCE      — under EACH role-activation combination (novice-only,
                         expert-only, both roles), the active-role x beta-arm
                         cells fill with exactly 40 each and any PREFIX of
                         arrivals is balanced to within one unit per cell; and
                         a run with NO active role raises a clear error.
  2. BLOCK ORDERS      — balanced over the 6 permutations within a session
                         (max-min <= 1) and uniform in aggregate across many
                         sessions (chi-square).
  3. TRUE-STATE PRIOR  — per-round draws respect prior = [0.8, 0.2].
  4. DGP               — the year grid is exactly n even points on
                         [x_min, x_max]; the raw continuous residuals
                         y_raw - baseline - beta*(t - t_mid) are N(0, sigma^2);
                         the DISPLAYED values are exactly round(y_raw); the
                         baseline is an integer uniform on
                         [baseline_min, baseline_max]; the rounding error has
                         the theoretical variance 1/12.
  5. DERIVED-FROM-DISPLAYED — the OLS slope fitted to the DISPLAYED integers
                         (the one the app stores) is unbiased, with sampling SD
                         equal to theory inflated by sqrt(1 + (1/12)/sigma^2)
                         (see reports/integer_rounding_effects.md).

Exits non-zero if any check fails.
"""

import math
import random
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from before.treatment_assignment import (
    active_roles, assign_sequence, block_order_choices, cell_combos, num_blocks,
    total_rounds,
)

# Load main/stimulus.py directly by path: importing the `main` package would
# execute its __init__.py, which needs an oTree installation.
import importlib.util

_spec = importlib.util.spec_from_file_location(
    'pilot_stimulus', Path(__file__).resolve().parent / 'main' / 'stimulus.py')
stimulus = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(stimulus)

# The session config used by the checks: the same defaults the app ships with.
from settings import DESIGN_DEFAULTS as CFG

N_PER_CELL = 40
N_PARTICIPANTS = N_PER_CELL * 4          # session size for the block-order checks
N_SESSIONS = 300                          # for aggregate uniformity checks
N_STATE_DRAWS = 200_000
N_DGP_DRAWS = 40_000

failures = []


def check(name, ok, detail):
    status = "PASS" if ok else "FAIL"
    print(f"[{status}] {name}: {detail}")
    if not ok:
        failures.append(name)


def chi_square_uniform(counts, n_categories=None):
    """Chi-square statistic against a uniform distribution over the keys."""
    total = sum(counts.values())
    k = n_categories or len(counts)
    exp = total / k
    return sum((c - exp) ** 2 / exp for c in counts.values()), k - 1


# --- upper-tail chi-square critical values (p = 0.001) by df ----------------
CHI2_CRIT_P001 = {1: 10.83, 3: 16.27, 5: 20.52, 7: 24.32, 15: 37.70, 40: 73.40}


def main():
    print(f"Config: {num_blocks(CFG)} blocks x {CFG['rounds_per_block']} rounds "
          f"= {total_rounds(CFG)} rounds; beta_pairs={CFG['beta_pairs']}; "
          f"prior={CFG['prior']}; sigma={CFG['sigma_eps']}; "
          f"baseline U[{CFG['baseline_min']}, {CFG['baseline_max']}]; "
          f"n_novice={CFG['n_novice']}, n_expert={CFG['n_expert']}\n")

    rng = random.Random(20260730)

    # ---- 1: cell balance under each role-activation combination --------------
    # The active-role cross (before/treatment_assignment.active_roles) must stay
    # exactly balanced whether the run recruits novices only, experts only, or
    # both roles — and must refuse to run when no role is active.
    scenarios = [
        ('novice-only', dict(role_novice=1, role_expert=0), ['NOVICE']),
        ('expert-only', dict(role_novice=0, role_expert=1), ['EXPERT']),
        ('both roles',  dict(role_novice=1, role_expert=1), ['NOVICE', 'EXPERT']),
    ]
    for label, flags, want_roles in scenarios:
        scfg = dict(CFG, **flags)
        active = active_roles(scfg)
        n_cells = len(active) * len(scfg['beta_pairs'])
        n_part = N_PER_CELL * n_cells
        asg = assign_sequence(n_part, scfg, random.Random(20260803))
        cells = Counter(a['cell'] for a in asg)
        roles_seen = set(a['role'] for a in asg)
        check(f"active roles resolve to {want_roles} ({label})",
              active == want_roles and roles_seen == set(want_roles),
              f"active={active}, roles_seen={sorted(roles_seen)}")
        check(f"{n_cells}-cell balance at {n_part} ({label})",
              len(cells) == n_cells and set(cells.values()) == {N_PER_CELL},
              f"counts={dict(sorted(cells.items()))}")
        # prefix balance: dropouts / partial recruitment cannot skew cells
        worst_spread = 0
        for prefix_len in range(1, n_part + 1):
            c = Counter(a['cell'] for a in asg[:prefix_len])
            spread = max(c.values()) - (min(c.values()) if len(c) == n_cells else 0)
            worst_spread = max(worst_spread, spread)
        check(f"every arrival prefix balanced to within 1 per cell ({label})",
              worst_spread <= 1, f"worst max-min spread={worst_spread}")

    # no active role must raise a clear error at assignment time
    no_role_raised = False
    try:
        active_roles(dict(CFG, role_novice=0, role_expert=0))
    except ValueError:
        no_role_raised = True
    check("no active role raises a clear error", no_role_raised,
          f"raised={no_role_raised}")

    # ---- 2: block orders (using the shipped default config) ------------------
    assignments = assign_sequence(N_PARTICIPANTS, CFG, rng)
    perms = block_order_choices(CFG)
    per_session = Counter(a['block_perm'] for a in assignments)
    check(f"block orders within a session cover all {len(perms)} permutations",
          len(per_session) == len(perms)
          and max(per_session.values()) - min(per_session.values()) <= 1,
          f"counts={dict(per_session)}")

    agg = Counter()
    for s in range(N_SESSIONS):
        srng = random.Random(1000 + s)
        for a in assign_sequence(100, CFG, srng):   # partial sessions too
            agg[a['block_perm']] += 1
    stat, df = chi_square_uniform(agg)
    crit = CHI2_CRIT_P001[df]
    check("block orders uniform across sessions (chi-square, p=0.001)",
          stat < crit, f"chi2={stat:.2f} (df={df}, crit={crit})")

    # ---- 3: true-state prior -------------------------------------------------
    prior = CFG['prior']
    pair = CFG['beta_pairs'][0]
    drng = random.Random(42)
    n_pos = sum(
        stimulus.draw_true_beta(pair, prior, drng) == pair[1]
        for _ in range(N_STATE_DRAWS))
    p_hat = n_pos / N_STATE_DRAWS
    se = math.sqrt(prior[1] * prior[0] / N_STATE_DRAWS)
    z = abs(p_hat - prior[1]) / se
    check(f"true state respects the {prior[0]}/{prior[1]} prior",
          z < 4, f"P(growing)={p_hat:.4f} (target {prior[1]}, z={z:.2f})")

    # ---- 4: the data-generating process --------------------------------------
    for n in sorted(set(CFG['n_novice']) | set(CFG['n_expert'])):
        xs = stimulus.make_x_grid(n, CFG)
        even = all(
            abs(xs[i + 1] - xs[i] - (CFG['x_max'] - CFG['x_min']) / (n - 1)) < 1e-12
            for i in range(n - 1))
        ok = (len(xs) == n and xs[0] == CFG['x_min'] and xs[-1] == CFG['x_max']
              and even)
        check(f"year grid n={n}: {n} even points on [{CFG['x_min']:g}, {CFG['x_max']:g}]",
              ok, f"first={xs[0]}, last={xs[-1]}, even={even}")

    beta = CFG['beta_pairs'][-1][1]  # the steepest arm in the config
    sigma = CFG['sigma_eps']
    n = CFG['n_expert'][0]
    t_mid = (CFG['x_min'] + CFG['x_max']) / 2.0
    grng = random.Random(7)
    resids, round_errs, slopes, baselines = [], [], [], Counter()
    rounding_exact = True
    xs = stimulus.make_x_grid(n, CFG)
    ss_xx = sum((x - sum(xs) / n) ** 2 for x in xs)
    for _ in range(N_DGP_DRAWS):
        xs_d, ys, ys_raw, baseline = stimulus.sample_points(n, beta, CFG, grng)
        baselines[baseline] += 1
        resids.extend(yr - baseline - beta * (x - t_mid)
                      for x, yr in zip(xs_d, ys_raw))
        round_errs.extend(y - yr for y, yr in zip(ys, ys_raw))
        rounding_exact = rounding_exact and all(
            y == int(round(yr)) for y, yr in zip(ys, ys_raw))
        # the slope the app stores: fitted to the DISPLAYED integers
        slopes.append(stimulus.ols_slope_se(xs_d, ys)[0])

    # baseline: integer uniform on [baseline_min, baseline_max]
    b_lo, b_hi = CFG['baseline_min'], CFG['baseline_max']
    in_range = all(b_lo <= b <= b_hi for b in baselines)
    stat, df = chi_square_uniform(baselines, n_categories=b_hi - b_lo + 1)
    crit = CHI2_CRIT_P001[df]
    check(f"baseline integer uniform on [{b_lo}, {b_hi}] (chi-square, p=0.001)",
          in_range and stat < crit,
          f"in_range={in_range}, chi2={stat:.2f} (df={df}, crit={crit})")

    # raw noise around the true line
    m = sum(resids) / len(resids)
    sd = math.sqrt(sum((r - m) ** 2 for r in resids) / (len(resids) - 1))
    z_mean = abs(m) / (sigma / math.sqrt(len(resids)))
    check("raw noise mean 0",
          z_mean < 4, f"mean={m:.5f} (z={z_mean:.2f})")
    check(f"raw noise SD {sigma}",
          abs(sd - sigma) / sigma < 0.01, f"sd={sd:.4f}")

    # displayed = round(raw), and the rounding error behaves as quantisation
    check("displayed values are exactly round(raw)", rounding_exact,
          f"checked {len(round_errs)} dots")
    in_half = all(-0.5 <= d <= 0.5 for d in round_errs)
    var_d = sum(d * d for d in round_errs) / len(round_errs)
    check("rounding error in [-0.5, 0.5] with variance ~ 1/12",
          in_half and abs(var_d - 1 / 12) / (1 / 12) < 0.05,
          f"in_half={in_half}, var={var_d:.5f} (theory {1/12:.5f})")

    # ---- 5: derived-from-displayed OLS slope ----------------------------------
    slope_mean = sum(slopes) / len(slopes)
    slope_sd = math.sqrt(
        sum((s - slope_mean) ** 2 for s in slopes) / (len(slopes) - 1))
    theo_sd_raw = sigma / math.sqrt(ss_xx)
    # integer display inflates the sampling SD by sqrt(1 + (1/12)/sigma^2)
    # (reports/integer_rounding_effects.md); no attenuation of the mean.
    theo_sd = theo_sd_raw * math.sqrt(1 + (1 / 12) / sigma ** 2)
    z_slope = abs(slope_mean - beta) / (theo_sd / math.sqrt(len(slopes)))
    check(f"OLS slope from DISPLAYED integers unbiased at beta={beta}",
          z_slope < 4, f"mean={slope_mean:.5f} (z={z_slope:.2f})")
    check("displayed-slope sampling SD matches rounding-inflated theory",
          abs(slope_sd - theo_sd) / theo_sd < 0.02,
          f"sd={slope_sd:.6f}, theory={theo_sd:.6f} "
          f"(raw theory {theo_sd_raw:.6f})")

    # ---- summary -------------------------------------------------------------
    print()
    if failures:
        print(f"{len(failures)} CHECK(S) FAILED: {failures}")
        return 1
    print("ALL CHECKS PASSED")
    return 0


if __name__ == '__main__':
    sys.exit(main())

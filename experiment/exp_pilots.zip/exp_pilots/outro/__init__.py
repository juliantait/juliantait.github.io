from otree.api import *
import json

from .payment_rule import select_paid_rounds

doc = """
Outro: compute the payment (paid rounds drawn at random from ALL rounds,
binarised scoring rule), show the result, and return the participant to
Prolific with the appropriate completion code. Participants who declined
consent normally leave from before/NoConsentWithdrawal; the NoConsent page
here is only a fallback ending in case one of them advances past that page
instead of clicking the withdraw button.
"""

PROLIFIC_COMPLETE_URL = 'https://app.prolific.com/submissions/complete?cc='


class C(BaseConstants):
    NAME_IN_URL = 'outro'
    PLAYERS_PER_GROUP = None
    NUM_ROUNDS = 1


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    bonus_total = models.FloatField(initial=0)       # scored allocations (+ quiz bonus)
    quiz_bonus_awarded = models.FloatField(initial=0)
    earned = models.FloatField(initial=0)            # base + bonus_total
    payment_detail = models.LongStringField(blank=True)  # JSON: per paid round
    # Optional free-text pilot feedback (outro/Remarks). Blank is allowed; the
    # page only appears when cfg['collect_remarks'] is on (pilot-only). Exported
    # with the outro data.
    remarks = models.LongStringField(blank=True, label='')


# FUNCTIONS

def _consented(player: Player):
    return getattr(player.participant, 'consented', False)


# PAGES

class NoConsent(Page):
    # Fallback only: non-consenters are expected to leave the study from
    # before/NoConsentWithdrawal. This page catches anyone who advanced past
    # it without clicking the withdraw button.
    template_name = 'outro/no_consent.html'

    @staticmethod
    def is_displayed(player: Player):
        return not _consented(player)

    @staticmethod
    def js_vars(player: Player):
        code = player.session.config['noconsent_code']
        return dict(completionlink=PROLIFIC_COMPLETE_URL + str(code))


class Remarks(Page):
    """PILOT-ONLY optional feedback page, in the slot a demographics page would
    occupy: after the task, before the results/payment page. One optional
    free-text box (blank allowed), stored on Player.remarks. Gated on
    cfg['collect_remarks'] so the final study sets it False and the page
    auto-skips, leaving the production flow unchanged. Only consenters see it
    (non-consenters route out before here)."""
    template_name = 'outro/remarks.html'
    form_model = 'player'
    form_fields = ['remarks']

    @staticmethod
    def is_displayed(player: Player):
        return _consented(player) and player.session.config.get('collect_remarks', True)


class Results(Page):
    template_name = 'outro/results.html'

    @staticmethod
    def is_displayed(player: Player):
        return _consented(player)

    @staticmethod
    def vars_for_template(player: Player):
        cfg = player.session.config
        part = player.participant

        # Compute once; re-rendering the page must not redraw the paid rounds.
        if not player.field_maybe_none('payment_detail'):
            details, allocation_total = select_paid_rounds(
                part.task_records or [], cfg)
            quiz_bonus = cfg['quiz_bonus']
            player.quiz_bonus_awarded = (
                quiz_bonus if (part.failed_attempts == 0 and quiz_bonus > 0) else 0)
            player.bonus_total = allocation_total + player.quiz_bonus_awarded
            player.earned = cfg['base_payment'] + player.bonus_total
            player.payment_detail = json.dumps(details)
            part.finish_reason = 'completed'
            player.payoff = cu(player.bonus_total)  # oTree bonus bookkeeping

        details = json.loads(player.payment_detail)
        paid_by_round = {d['round']: d for d in details}

        # EVERY round (all of them), in play order, with the paid rounds flagged and
        # their realised outcome overlaid from the persisted payment detail.
        all_rounds = []
        for rec in sorted(part.task_records or [], key=lambda r: r['round']):
            pos_pts = round(rec['allocation_pos'] * 100)
            paid = paid_by_round.get(rec['round'])
            all_rounds.append(dict(
                round=rec['round'],
                alloc_pos=pos_pts,
                alloc_zero=100 - pos_pts,
                state_label='Growing' if rec['state_is_pos'] else 'Stable',
                is_paid=paid is not None,
                won=bool(paid['won']) if paid else False,
                payoff_cu=cu(paid['payoff']) if paid else None,
            ))

        return {
            'all_rounds': all_rounds,
            'paid_rounds_total': len(details),
            'base_payment': cu(cfg['base_payment']),
            'bonus_total': cu(player.bonus_total),
            'earned': cu(player.earned),
            'quiz_bonus_awarded': cu(player.quiz_bonus_awarded),
            'show_quiz_bonus': player.quiz_bonus_awarded > 0,
        }

    @staticmethod
    def js_vars(player: Player):
        code = player.session.config['cc_code']
        return dict(completionlink=PROLIFIC_COMPLETE_URL + str(code))


page_sequence = [NoConsent, Remarks, Results]

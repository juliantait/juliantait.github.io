"""
Payment rule for the calibration pilot.

Design: pay `paid_rounds_total` rounds drawn at random from ALL completed
rounds (default two out of 24 — NOT one per block), each paid by the
Hossain-Okui (2013) binarised quadratic scoring rule against the realised
true state (see main/scoring.py) with prize `scoring_prize` — the same rule
as the main study. The base payment is added on top for completing.

Everything comes from the session config; nothing is hard-coded. No oTree
imports, so the logic is unit-testable standalone.
"""

import random

from main.scoring import score_allocation, mass_on_state


def select_paid_rounds(task_records, cfg, rng=None):
    """Draw the paid rounds (from ALL rounds) and score them.

    `task_records` is the per-round list stored by main/AllocationScreen (one
    dict per completed round with keys: round, block_number, round_in_block,
    n_points, true_beta, state_is_pos, baseline, allocation_pos, rt_ms).

    Returns (details, total) where `details` is one dict per paid round.
    """
    rng = rng or random
    prize = cfg['scoring_prize']
    n_paid = min(cfg['paid_rounds_total'], len(task_records))

    chosen = rng.sample(list(task_records), n_paid)
    details = []
    total = 0.0
    for rec in sorted(chosen, key=lambda r: r['round']):
        u = rng.random()
        payoff, win_prob, won = score_allocation(
            rec['allocation_pos'], rec['state_is_pos'], prize, u)
        details.append(dict(
            block_number=rec['block_number'],
            round=rec['round'],
            round_in_block=rec['round_in_block'],
            allocation_pos=rec['allocation_pos'],
            state_is_pos=rec['state_is_pos'],
            true_beta=rec['true_beta'],
            mass_on_state=mass_on_state(rec['allocation_pos'], rec['state_is_pos']),
            win_prob=win_prob,
            won=won,
            payoff=payoff,
        ))
        total += payoff
    return details, total

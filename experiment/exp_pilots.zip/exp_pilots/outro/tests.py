import json

from otree.api import Bot, Submission, expect

from . import NoConsent, Remarks, Results


class PlayerBot(Bot):
    def play_round(self):
        cfg = self.session.config

        if not self.participant.consented:
            yield Submission(NoConsent, check_html=False)
            return

        num_blocks = len(cfg['n_novice'])
        total_rounds = num_blocks * cfg['rounds_per_block']
        n_paid = min(cfg['paid_rounds_total'], total_rounds)

        # One task record per round, with the allocation the main-app bot submitted.
        records = self.participant.task_records or []
        expect(len(records), total_rounds)
        for rec in records:
            expect(rec['allocation_pos'], ((rec['round'] * 7) % 101) / 100.0)
            expect(rec['rt_ms'], 1234.5)
            expect(cfg['baseline_min'] <= rec['baseline'] <= cfg['baseline_max'],
                   True)

        # Pilot-only remarks page (when collect_remarks is on): one optional
        # free-text box, stored on the player and exported. Submit a value and
        # confirm it round-trips.
        if cfg.get('collect_remarks', True):
            yield Submission(
                Remarks, dict(remarks='pilot bot feedback'), check_html=False)
            expect(self.player.remarks, 'pilot bot feedback')

        yield Submission(Results, check_html=False)

        player = self.player
        details = json.loads(player.payment_detail)
        # exactly paid_rounds_total DISTINCT rounds drawn from ALL rounds
        expect(len(details), n_paid)
        paid_rounds = [d['round'] for d in details]
        expect(len(set(paid_rounds)), n_paid)
        expect(all(1 <= r <= total_rounds for r in paid_rounds), True)
        expect(player.earned, cfg['base_payment'] + player.bonus_total)
        max_allocation_bonus = n_paid * cfg['scoring_prize']
        expect(player.bonus_total <= max_allocation_bonus + cfg['quiz_bonus'], True)

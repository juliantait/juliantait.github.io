#!/usr/bin/env bash
#
# Container entrypoint: serve the calibration pilot on port 8102.
#
#   1. initialise the database — PRESERVED across container restarts unless
#      RESET_DB=1 is set (a restart mid-study must not wipe participant data;
#      mount /app/db.sqlite3's directory as a volume for full safety)
#   2. start oTree's production server in the background
#   3. wait for it, then bind a 'pilot_test' session to the 'exp_pilots' room
#      via the REST API (the oTree CLI cannot bind a session to a room);
#      non-fatal if it already exists or if the API needs auth
#   4. keep the server in the foreground so the container stays alive
#
set -euo pipefail

export PATH="/usr/local/bin:${HOME:-/root}/.local/bin:${PATH}"

PORT="${PORT:-8102}"

# Keep the sqlite file under /app/data so a docker volume mounted there
# (-v exp-pilots-db:/app/data) preserves participant data across restarts.
mkdir -p data
ln -sf data/db.sqlite3 db.sqlite3

if [[ "${RESET_DB:-}" == "1" || ! -f data/db.sqlite3 ]]; then
    rm -f data/db.sqlite3
    otree resetdb --noinput
fi

otree prodserver 0.0.0.0:"$PORT" &
SERVER_PID=$!

python3 - <<PYEOF
import json, os, time, urllib.request, urllib.error

BASE = 'http://localhost:${PORT}'

def server_ready():
    try:
        urllib.request.urlopen(BASE + '/api/rooms', timeout=2)
        return True
    except Exception:
        return False

for _ in range(120):
    if server_ready():
        break
    time.sleep(1)
else:
    raise SystemExit('start.sh: server did not become ready on :${PORT}')

# Bind a test session to the room so /room/exp_pilots works immediately.
payload = json.dumps({
    'session_config_name': 'pilot_test',
    'num_participants': 16,
    'room_name': 'exp_pilots',
}).encode()
req = urllib.request.Request(
    BASE + '/api/sessions',
    data=payload,
    headers={'Content-Type': 'application/json'},
    method='POST',
)
try:
    resp = urllib.request.urlopen(req, timeout=15)
    print('start.sh: pilot_test bound to exp_pilots ->', resp.read().decode())
except urllib.error.HTTPError as e:
    # Already bound (container restart) or REST auth in production; not fatal.
    print('start.sh: /api/sessions returned', e.code, e.read().decode())
PYEOF

wait "$SERVER_PID"

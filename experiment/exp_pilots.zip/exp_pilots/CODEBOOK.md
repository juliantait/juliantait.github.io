# exp_pilots — data CODEBOOK

Every custom variable a data analyst meets in the oTree export, grouped by the
level it lives at. The task is single-player: no groups, no group-level fields.

> **Keep this current.** This codebook is hand-maintained and will silently go
> stale if fields change. When you add, rename, or remove a field in
> `settings.py` (`PARTICIPANT_FIELDS`), `before/`, `intro/`, `main/`, or
> `outro/`, update the matching row here in the same commit. Value codes
> (especially `consent`, `completed`, `finish_reason`) are part of the contract
> — change the code, change the row.

Scope note: this documents the project's **custom** fields. The export also
carries oTree's standard columns (`participant.code`, `participant.label` — the
Prolific PID, see below — `participant._current_app_name`, `session.code`,
`session.config`, per-app `player.id_in_group`, `player.payoff`, etc.); those
follow oTree's own conventions and are not repeated here.

How the export is shaped: oTree emits **one wide row per participant** for the
one-round apps (`before`, `intro`, `outro`) and **one row per round** for the
24-round `main` app (via `otree export` / the admin Data tab). Participant
fields repeat on every one of a participant's rows.

---

## 1. Participant-level

`PARTICIPANT_FIELDS` in `settings.py` (persist across apps; one value per
participant). Treatment cell is written once in
`before/treatment_assignment.py` at session creation; flow-state fields are
written on the consent page and at the end.

| Field | Type | Units / codes | Set when | Meaning |
|---|---|---|---|---|
| `label` (oTree std) | str | Prolific PID | consent page | Prolific participant ID. URL sets it via `?participant_label={{%PROLIFIC_PID%}}`; the consent form's hidden `prolific_id` is a fallback that back-fills `label`. Match bonuses/completions on this. |
| `pilot_role` | str | `NOVICE` \| `EXPERT` | session creation | Between-participant ROLE. Sets ONLY which n-list the blocks draw from; invisible to the participant (no label, framing, or pay difference). |
| `pilot_beta_pair` | list[float] | e.g. `[0.0, 0.02]` | session creation | The participant's two candidate per-year slopes (stable = 0, growing > 0), fixed for all rounds. `0.02` = the "2 coconuts per 100 years" arm. |
| `pilot_beta_pos` | float | per-year slope | session creation | The growing candidate slope = `pilot_beta_pair[1]`. |
| `pilot_block_pos`* | — | — | — | *No such field.* Position info lives in `pilot_block_perm`. (Listed in the task brief but not in the code; see "Surprises".) |
| `pilot_block_perm` | list[int] | 0-based block indices, e.g. `[2, 0, 1]` | session creation | Within-participant permutation of block indices = the randomised block order. |
| `pilot_block_ns` | list[int] | n per block position, e.g. `[5, 3, 4]` | session creation | Realised record count n in block 1, 2, 3 (= the role's n-list reordered by `pilot_block_perm`). Never shown to the participant. |
| `pilot_cell` | str | `ROLE\|beta_pos`, e.g. `NOVICE\|0.02` | session creation | The 4-cell treatment label (ROLE × BETA ARM). |
| `consented` | bool | True / False | consent page (`before/Welcome`) | Whether the participant consented. String/bool mirror of `consent`. |
| `finish_reason` | str | `completed` \| `noconsent` | consent page; re-affirmed at `outro/Results` | `noconsent` if consent declined, else `completed`. |
| `failed_attempts` | int | count (0 = quiz-bonus eligible) | incremented in `intro` quiz | Total wrong quiz submissions across all quiz attempts. Participant-level mirror of intro's `num_failed_attempts`. |
| `task_records` | JSON list[dict] | see §5 | appended per round in `main` | Per-round records used for the payment draw and as a flat export convenience. |
| `consent` | int | **1** = consented, **0** = declined | consent page | Numeric mirror of `consented`, for analysis. |
| `completed` | int | **1** = finished the full study; **-333** = declined consent and exited immediately after the consent page | `-333` at consent page (if declined); `1` at `outro/Results` | Numeric exit code. **`-333` means the participant did NOT consent and left via the withdrawal page right after consent — no task data.** **`1` means they reached the final results/payment page having done the whole study.** A consenter who abandons mid-task leaves `completed` **unset/empty** (neither code): empty ≠ completed. |

---

## 2. Round-level — `main` player (24 rows per participant)

Fields on `main.Player` (`main/__init__.py`). One row per round. The
treatment "copies" repeat participant facts per round so the flat per-round
export is self-contained.

| Field | Type | Units / codes | Set when | Meaning |
|---|---|---|---|---|
| `assigned_role` | str | `NOVICE` \| `EXPERT` | `creating_session` | Per-round copy of `pilot_role` (named `assigned_role` because `role` is reserved). |
| `beta_pos` | float | per-year slope | `creating_session` | Per-round copy of `pilot_beta_pos` (the growing candidate slope). |
| `block_number` | int | 1-based | `creating_session` | Which block this round belongs to (1..3). |
| `round_in_block` | int | 1-based | `creating_session` | Position within the block (1..`rounds_per_block`). |
| `n_points` | int | count | `creating_session` | Number of observation years (dots) shown this round = `pilot_block_ns[block_index]`. Never shown to the participant. |
| `true_beta` | float | per-year slope | `creating_session` | The realised true slope, drawn fresh each round from the prior (either `0.0` or `beta_pos`). |
| `state_is_pos` | bool | True = growing | `creating_session` | True iff `true_beta == beta_pos` (island is Growing). |
| `baseline` | int | coconuts | `creating_session` | Island's average production at the mid-window year (integer, uniform on `[baseline_min, baseline_max]`). Also the y-axis centre of the chart. |
| `xy_data` | JSON | `{x, y, y_raw}` — see §5 | `creating_session` | The realised stimulus: `x` years, `y` displayed integers (**the stimulus**), `y_raw` the continuous draws underneath. Both recorded so the analysis can use exactly what was displayed while raw draws let one verify the randomness is genuine. |
| `beta_hat` | float | per-year slope | `creating_session` | OLS slope fitted to the **displayed integers** y. Derived convenience (reconstructable from `xy_data`). |
| `se` | float | slope SE | `creating_session` | OLS slope standard error from the displayed y (`None`/blank if undefined, e.g. n too small). |
| `llr` | float | log-likelihood ratio | `creating_session` | Log-likelihood ratio, growing vs stable, of the displayed y. |
| `posterior` | float | prob (0..1) | `creating_session` | Exact Bayesian posterior on Growing given the displayed y and the prior. |
| `allocation_pos_pct` | int | 0..100 points | form submit (`AllocationScreen`) | The bet: points placed on **Growing** (of 100); Stable gets the rest. The one and only elicited object. |
| `rt_ms` | float | milliseconds | form submit | Response time from page load to submit. |

**All derived stats (`beta_hat`, `se`, `llr`, `posterior`) are computed from
the DISPLAYED integers, never from `y_raw`** — the analysis must describe the
stimulus participants actually saw.

---

## 3. Round-level — `intro` player (comprehension quiz, 1 row per participant)

Fields on `intro.Player` (`intro/__init__.py`, generated from
`intro/quiz_items.py`). Each quiz field stores the chosen option's value
string; correctness is checked against the item's `answer`.

| Field | Type | Value codes | Meaning |
|---|---|---|---|
| `num_failed_attempts` | int | count | Wrong quiz submissions by this participant (mirrored up to participant `failed_attempts`). |
| `quiz_prior` | str | choice text | "Out of 1,000 islands, how many grow?" (correct: `200`). |
| `quiz_dot` | str | choice text | "What does one dot show?" (correct: the island's production in one year). |
| `quiz_payment` | str | choice text | "How many rounds count for real payment?" (correct: two, drawn at random from all rounds). |
| `quiz_betting` | str | choice text | "What determines your chance of the prize?" (correct: how many points were on the island's actual type). |
| `quiz_independence` | str | choice text | "What does this island tell you about the next?" (correct: nothing). |

Quiz answers are only sent to the browser when `DEBUG` is on; with
`verify_quiz=False` (the `pilot_test` config) answers are not validated.

---

## 4. Outro / payment — `outro` player (1 row per participant)

Fields on `outro.Player` (`outro/__init__.py`). Payment is computed once at
`outro/Results` and cached so re-rendering never redraws the paid rounds.

| Field | Type | Units | Set when | Meaning |
|---|---|---|---|---|
| `bonus_total` | float | GBP | `outro/Results` | Total bonus = summed paid-round payoffs + `quiz_bonus_awarded`. This is the Prolific bonus to pay (matched on `label`). |
| `quiz_bonus_awarded` | float | GBP | `outro/Results` | Quiz bonus, awarded only if `failed_attempts == 0` and `quiz_bonus > 0` (config `quiz_bonus`, currently `0.00`, so normally 0). |
| `earned` | float | GBP | `outro/Results` | `base_payment` + `bonus_total` (the participant's total study earnings). |
| `payoff` (oTree std) | currency | GBP | `outro/Results` | oTree's own payoff bookkeeping, set to `bonus_total`. |
| `payment_detail` | JSON list[dict] | see §5 | `outro/Results` | One dict per **paid** round drawn from all rounds. |
| `remarks` | str | free text | `outro/Remarks` | Optional pilot feedback (blank allowed). Page shown only when `collect_remarks` is on; auto-skips in production. Not part of the final study. |

**Paid-round selection.** `paid_rounds_total` (=2) rounds are drawn at random
from **ALL** rounds (not one per block; `outro/payment_rule.py`), scored by the
binarised rule below, prize `scoring_prize` (£0.50) each. Base pay is added on
top.

**Win-probability rule (Hossain & Okui 2013 binarised quadratic).** With mass
`m` on the realised state, `win_prob = 1 - (1 - m)^2`. If `a` points sat on the
island's **actual** type, `m = a/100` and `win_prob = 1 - ((100 - a)/100)^2`.
The prize is won iff a uniform draw ≤ `win_prob`. Truthful reporting of the
posterior is optimal regardless of risk attitude.

---

## 5. Nested JSON structures

### `xy_data` (string on `main.Player`)
`{"x": [...], "y": [...], "y_raw": [...]}` — all three lists length `n_points`.
- `x` — realised observation years (floats, evenly spaced over `[x_min, x_max]` = `[0, 100]`).
- `y` — **displayed integer** production per year: `round(y_raw)`. THE stimulus; every derived stat is computed from these.
- `y_raw` — the continuous draws underneath at full precision (`baseline + beta*(t - t_mid) + eps`). Bookkeeping only, to verify randomness is genuine.

### `task_records` (list on `participant`, one dict per round)
Appended in `main/AllocationScreen.before_next_page`. Keys:
`round`, `block_number`, `round_in_block`, `n_points`, `true_beta`,
`state_is_pos`, `baseline`, `allocation_pos` (fraction on Growing, 0..1 =
`allocation_pos_pct / 100`), `rt_ms`.

### `payment_detail` (string on `outro.Player`, one dict per paid round)
Built by `outro/payment_rule.select_paid_rounds`. Keys:
`block_number`, `round`, `round_in_block`, `allocation_pos` (0..1),
`state_is_pos`, `true_beta`, `mass_on_state` (mass on the realised state),
`win_prob` (`1 - (1 - m)^2`), `won` (bool), `payoff` (GBP: `scoring_prize` or 0).

---

## Design constants vs. estimated quantities

Values like `n_points`, `baseline` bounds, `prior`, `sigma_eps`, prize amounts,
`min_view_seconds`, and the beta arms are **design constants** set in
`settings.py` (`DESIGN_DEFAULTS`) — written as-is. Means, slopes, posteriors and
sample sizes are computed downstream from the recorded data.
